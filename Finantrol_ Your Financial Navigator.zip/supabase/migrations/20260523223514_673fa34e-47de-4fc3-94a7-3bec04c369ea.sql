
-- 1) Despesas: novos campos
ALTER TABLE public.despesas
  ADD COLUMN IF NOT EXISTS metodo_pagamento text NOT NULL DEFAULT 'dinheiro',
  ADD COLUMN IF NOT EXISTS cartao_id uuid;

ALTER TABLE public.despesas
  DROP CONSTRAINT IF EXISTS despesas_metodo_pagamento_check;
ALTER TABLE public.despesas
  ADD CONSTRAINT despesas_metodo_pagamento_check
  CHECK (metodo_pagamento IN ('dinheiro','pix','debito','credito','transferencia','boleto'));

-- 2) Faturas
CREATE TABLE IF NOT EXISTS public.faturas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  cartao_id uuid NOT NULL,
  mes_referencia date NOT NULL, -- primeiro dia do mês de vencimento
  vencimento date NOT NULL,
  valor_total numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'aberta' CHECK (status IN ('aberta','paga')),
  paga_em timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (cartao_id, mes_referencia)
);
ALTER TABLE public.faturas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS faturas_all_own ON public.faturas;
CREATE POLICY faturas_all_own ON public.faturas
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 3) Itens da fatura
CREATE TABLE IF NOT EXISTS public.fatura_itens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  fatura_id uuid NOT NULL REFERENCES public.faturas(id) ON DELETE CASCADE,
  despesa_id uuid NOT NULL REFERENCES public.despesas(id) ON DELETE CASCADE,
  valor numeric NOT NULL,
  parcela_atual int NOT NULL DEFAULT 1,
  parcela_total int NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.fatura_itens ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS fatura_itens_all_own ON public.fatura_itens;
CREATE POLICY fatura_itens_all_own ON public.fatura_itens
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_fatura_itens_fatura ON public.fatura_itens(fatura_id);
CREATE INDEX IF NOT EXISTS idx_fatura_itens_despesa ON public.fatura_itens(despesa_id);

-- 4) Atualizar trigger de saldo: ignorar crédito
CREATE OR REPLACE FUNCTION public.despesas_saldo_trigger()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.metodo_pagamento <> 'credito' THEN
      PERFORM public.apply_saldo_delta(NEW.user_id, -NEW.valor);
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    -- reverte antigo, aplica novo (se não credito)
    IF OLD.metodo_pagamento <> 'credito' THEN
      PERFORM public.apply_saldo_delta(OLD.user_id, OLD.valor);
    END IF;
    IF NEW.metodo_pagamento <> 'credito' THEN
      PERFORM public.apply_saldo_delta(NEW.user_id, -NEW.valor);
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.metodo_pagamento <> 'credito' THEN
      PERFORM public.apply_saldo_delta(OLD.user_id, OLD.valor);
    END IF;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$function$;

-- 5) Helper: obter/criar fatura para (cartao, data)
CREATE OR REPLACE FUNCTION public.get_or_create_fatura(_user_id uuid, _cartao_id uuid, _data date)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _fechamento int;
  _vencimento_dia int;
  _ref date;
  _venc date;
  _fid uuid;
BEGIN
  SELECT fechamento, vencimento INTO _fechamento, _vencimento_dia
    FROM cartoes WHERE id = _cartao_id AND user_id = _user_id;
  IF _fechamento IS NULL THEN RAISE EXCEPTION 'Cartão não encontrado'; END IF;

  -- Se data < fechamento do mês: fatura fecha esse mês; senão próximo mês
  IF EXTRACT(DAY FROM _data)::int < _fechamento THEN
    _ref := date_trunc('month', _data)::date;
  ELSE
    _ref := (date_trunc('month', _data) + interval '1 month')::date;
  END IF;

  -- Vencimento: se vencimento_dia >= fechamento, mesmo mês de ref; senão mês seguinte
  IF _vencimento_dia >= _fechamento THEN
    _venc := (_ref + (LEAST(_vencimento_dia, EXTRACT(DAY FROM (_ref + interval '1 month - 1 day'))::int) - 1) * interval '1 day')::date;
  ELSE
    _venc := ((_ref + interval '1 month') + (LEAST(_vencimento_dia, EXTRACT(DAY FROM (_ref + interval '2 month - 1 day'))::int) - 1) * interval '1 day')::date;
  END IF;

  INSERT INTO faturas(user_id, cartao_id, mes_referencia, vencimento, valor_total, status)
  VALUES (_user_id, _cartao_id, _ref, _venc, 0, 'aberta')
  ON CONFLICT (cartao_id, mes_referencia) DO UPDATE SET mes_referencia = EXCLUDED.mes_referencia
  RETURNING id INTO _fid;

  RETURN _fid;
END;
$$;

-- 6) Trigger de despesas para gerar itens de fatura
CREATE OR REPLACE FUNCTION public.despesas_fatura_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  i int;
  n int;
  parc_valor numeric;
  parc_data date;
  fid uuid;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.metodo_pagamento = 'credito' AND NEW.cartao_id IS NOT NULL THEN
      n := GREATEST(NEW.parcela, 1);
      parc_valor := round((NEW.valor / n)::numeric, 2);
      FOR i IN 1..n LOOP
        parc_data := (NEW.data + ((i - 1) || ' months')::interval)::date;
        fid := public.get_or_create_fatura(NEW.user_id, NEW.cartao_id, parc_data);
        INSERT INTO fatura_itens(user_id, fatura_id, despesa_id, valor, parcela_atual, parcela_total)
        VALUES (NEW.user_id, fid, NEW.id, parc_valor, i, n);
        UPDATE faturas SET valor_total = valor_total + parc_valor WHERE id = fid;
      END LOOP;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    -- restaurar valor das faturas afetadas (somente se abertas)
    UPDATE faturas f SET valor_total = GREATEST(0, valor_total - sub.total)
    FROM (
      SELECT fatura_id, SUM(valor) AS total FROM fatura_itens
      WHERE despesa_id = OLD.id GROUP BY fatura_id
    ) sub
    WHERE f.id = sub.fatura_id AND f.status = 'aberta';
    -- cascade exclui fatura_itens
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    -- simplificação: se mudou algo relevante, re-emitir
    IF (OLD.metodo_pagamento IS DISTINCT FROM NEW.metodo_pagamento)
       OR (OLD.cartao_id IS DISTINCT FROM NEW.cartao_id)
       OR (OLD.valor IS DISTINCT FROM NEW.valor)
       OR (OLD.parcela IS DISTINCT FROM NEW.parcela)
       OR (OLD.data IS DISTINCT FROM NEW.data) THEN
      -- remove antigos e recalcula faturas abertas
      UPDATE faturas f SET valor_total = GREATEST(0, valor_total - sub.total)
      FROM (
        SELECT fatura_id, SUM(valor) AS total FROM fatura_itens
        WHERE despesa_id = OLD.id GROUP BY fatura_id
      ) sub
      WHERE f.id = sub.fatura_id AND f.status = 'aberta';
      DELETE FROM fatura_itens WHERE despesa_id = OLD.id;

      IF NEW.metodo_pagamento = 'credito' AND NEW.cartao_id IS NOT NULL THEN
        n := GREATEST(NEW.parcela, 1);
        parc_valor := round((NEW.valor / n)::numeric, 2);
        FOR i IN 1..n LOOP
          parc_data := (NEW.data + ((i - 1) || ' months')::interval)::date;
          fid := public.get_or_create_fatura(NEW.user_id, NEW.cartao_id, parc_data);
          INSERT INTO fatura_itens(user_id, fatura_id, despesa_id, valor, parcela_atual, parcela_total)
          VALUES (NEW.user_id, fid, NEW.id, parc_valor, i, n);
          UPDATE faturas SET valor_total = valor_total + parc_valor WHERE id = fid;
        END LOOP;
      END IF;
    END IF;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_despesas_fatura ON public.despesas;
CREATE TRIGGER trg_despesas_fatura
AFTER INSERT OR UPDATE OR DELETE ON public.despesas
FOR EACH ROW EXECUTE FUNCTION public.despesas_fatura_trigger();

-- 7) Pagar fatura
CREATE OR REPLACE FUNCTION public.pagar_fatura(_fatura_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE _uid uuid; _valor numeric; _status text;
BEGIN
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_total, status INTO _valor, _status FROM faturas WHERE id = _fatura_id AND user_id = _uid;
  IF _valor IS NULL THEN RAISE EXCEPTION 'Fatura não encontrada'; END IF;
  IF _status = 'paga' THEN RAISE EXCEPTION 'Fatura já está paga'; END IF;
  IF _valor <= 0 THEN RAISE EXCEPTION 'Fatura sem valor'; END IF;
  PERFORM public.apply_saldo_delta(_uid, -_valor);
  UPDATE faturas SET status = 'paga', paga_em = now() WHERE id = _fatura_id;
END;
$$;

-- 8) Permissões: revogar PUBLIC e dar a authenticated
REVOKE EXECUTE ON FUNCTION public.get_or_create_fatura(uuid, uuid, date) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.pagar_fatura(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pagar_fatura(uuid) TO authenticated;
