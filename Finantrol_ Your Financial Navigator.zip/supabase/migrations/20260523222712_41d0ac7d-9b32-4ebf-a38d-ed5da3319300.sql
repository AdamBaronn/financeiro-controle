
-- Aportar: agora SEM debitar saldo do usuário
CREATE OR REPLACE FUNCTION public.investimento_aportar(_inv_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid; _vi numeric; _va numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_investido, valor_atual INTO _vi, _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _vi IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  UPDATE investimentos
     SET valor_investido = _vi + _valor,
         valor_atual = _va + _valor
   WHERE id = _inv_id;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor)
  VALUES (_uid, _inv_id, 'aporte', _valor);
END; $$;

-- Registrar lucro ou perda (não toca no saldo)
CREATE OR REPLACE FUNCTION public.investimento_lucro(_inv_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid; _va numeric; _novo numeric;
BEGIN
  IF _valor IS NULL OR _valor = 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_atual INTO _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _va IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  _novo := _va + _valor;
  IF _novo < 0 THEN RAISE EXCEPTION 'Resultado deixaria o investimento negativo'; END IF;
  UPDATE investimentos SET valor_atual = _novo WHERE id = _inv_id;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor)
  VALUES (_uid, _inv_id, CASE WHEN _valor >= 0 THEN 'lucro' ELSE 'perda' END, ABS(_valor));
END; $$;

-- Reinvestir lucro: move parte do lucro para o capital investido
CREATE OR REPLACE FUNCTION public.investimento_reinvestir_lucro(_inv_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid; _vi numeric; _va numeric; _lucro numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_investido, valor_atual INTO _vi, _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _vi IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  _lucro := _va - _vi;
  IF _lucro <= 0 THEN RAISE EXCEPTION 'Não há lucro disponível para reinvestir'; END IF;
  IF _valor > _lucro THEN RAISE EXCEPTION 'Lucro disponível: R$ %', round(_lucro::numeric, 2); END IF;
  UPDATE investimentos SET valor_investido = _vi + _valor WHERE id = _inv_id;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor)
  VALUES (_uid, _inv_id, 'reinvestimento', _valor);
END; $$;

REVOKE EXECUTE ON FUNCTION public.investimento_lucro(uuid,numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_reinvestir_lucro(uuid,numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.investimento_lucro(uuid,numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_reinvestir_lucro(uuid,numeric) TO authenticated;
