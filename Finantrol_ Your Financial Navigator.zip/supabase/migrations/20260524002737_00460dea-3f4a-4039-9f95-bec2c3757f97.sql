
-- Revoke EXECUTE from PUBLIC on all SECURITY DEFINER functions, grant only where needed (authenticated for client-callable RPCs)

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.receitas_saldo_trigger() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.despesas_saldo_trigger() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.despesas_fatura_trigger() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.apply_saldo_delta(uuid, numeric) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.get_or_create_fatura(uuid, uuid, date) FROM PUBLIC, anon, authenticated;

REVOKE EXECUTE ON FUNCTION public.pagar_fatura(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.meta_aportar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.meta_resgatar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_lucro(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_reinvestir_lucro(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_comprar(uuid, numeric) FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.pagar_fatura(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.meta_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.meta_resgatar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_lucro(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_reinvestir_lucro(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_comprar(uuid, numeric) TO authenticated;
