DROP POLICY IF EXISTS "avatar_user_read" ON storage.objects;
DROP POLICY IF EXISTS "avatar_user_upload" ON storage.objects;
DROP POLICY IF EXISTS "avatar_user_update" ON storage.objects;
DROP POLICY IF EXISTS "avatar_user_delete" ON storage.objects;