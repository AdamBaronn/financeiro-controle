
-- Function: ajusta saldo do profile com base em delta
CREATE OR REPLACE FUNCTION public.apply_saldo_delta(_user_id uuid, _delta numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
     SET saldo_atual = COALESCE(saldo_atual, 0) + _delta,
         updated_at = now()
   WHERE id = _user_id;
END;
$$;

-- Receitas: + soma ao saldo
CREATE OR REPLACE FUNCTION public.receitas_saldo_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.apply_saldo_delta(NEW.user_id, NEW.valor);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    PERFORM public.apply_saldo_delta(NEW.user_id, NEW.valor - OLD.valor);
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM public.apply_saldo_delta(OLD.user_id, -OLD.valor);
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

-- Despesas: - subtrai do saldo
CREATE OR REPLACE FUNCTION public.despesas_saldo_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public.apply_saldo_delta(NEW.user_id, -NEW.valor);
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    PERFORM public.apply_saldo_delta(NEW.user_id, -(NEW.valor - OLD.valor));
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM public.apply_saldo_delta(OLD.user_id, OLD.valor);
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_receitas_saldo ON public.receitas;
CREATE TRIGGER trg_receitas_saldo
AFTER INSERT OR UPDATE OR DELETE ON public.receitas
FOR EACH ROW EXECUTE FUNCTION public.receitas_saldo_trigger();

DROP TRIGGER IF EXISTS trg_despesas_saldo ON public.despesas;
CREATE TRIGGER trg_despesas_saldo
AFTER INSERT OR UPDATE OR DELETE ON public.despesas
FOR EACH ROW EXECUTE FUNCTION public.despesas_saldo_trigger();
