CREATE OR REPLACE FUNCTION public.investimento_aportar(_inv_id uuid, _valor numeric)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE _uid uuid; _vi numeric; _va numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_investido, valor_atual INTO _vi, _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _vi IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  UPDATE profiles SET saldo_atual = COALESCE(saldo_atual,0) - _valor, updated_at = now() WHERE id = _uid;
  UPDATE investimentos
     SET valor_investido = _vi + _valor,
         valor_atual = _va + _valor
   WHERE id = _inv_id;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor) VALUES (_uid, _inv_id, 'aporte', _valor);
END; $function$;

CREATE OR REPLACE FUNCTION public.investimento_resgatar(_inv_id uuid, _valor numeric)
 RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE _uid uuid; _vi numeric; _va numeric; _novo_va numeric; _novo_vi numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_investido, valor_atual INTO _vi, _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _vi IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  IF _valor > _va THEN RAISE EXCEPTION 'Valor maior que o disponível no investimento'; END IF;
  _novo_va := _va - _valor;
  _novo_vi := CASE WHEN _va > 0 THEN _vi * (_novo_va / _va) ELSE 0 END;
  UPDATE investimentos
     SET valor_atual = _novo_va,
         valor_investido = _novo_vi
   WHERE id = _inv_id;
  UPDATE profiles SET saldo_atual = COALESCE(saldo_atual,0) + _valor, updated_at = now() WHERE id = _uid;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor) VALUES (_uid, _inv_id, 'resgate', _valor);
END; $function$;

REVOKE EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) TO authenticated;