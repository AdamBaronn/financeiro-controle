
REVOKE EXECUTE ON FUNCTION public.apply_saldo_delta(uuid, numeric) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.receitas_saldo_trigger() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.despesas_saldo_trigger() FROM PUBLIC, anon, authenticated;
