-- Revoke broad execute, then grant only what the app needs

-- Internal helpers / trigger functions: nobody should call these directly
REVOKE EXECUTE ON FUNCTION public.apply_saldo_delta(uuid, numeric) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.receitas_saldo_trigger() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.despesas_saldo_trigger() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- App-callable RPCs: only authenticated users
REVOKE EXECUTE ON FUNCTION public.meta_aportar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.meta_resgatar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.meta_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.meta_resgatar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) TO authenticated;