
-- History tables
CREATE TABLE public.meta_movimentacoes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  meta_id uuid NOT NULL REFERENCES public.metas(id) ON DELETE CASCADE,
  tipo text NOT NULL CHECK (tipo IN ('aporte','resgate')),
  valor numeric NOT NULL CHECK (valor > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.meta_movimentacoes ENABLE ROW LEVEL SECURITY;
CREATE POLICY meta_mov_all_own ON public.meta_movimentacoes FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_meta_mov_meta ON public.meta_movimentacoes(meta_id, created_at DESC);

CREATE TABLE public.investimento_movimentacoes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  investimento_id uuid NOT NULL REFERENCES public.investimentos(id) ON DELETE CASCADE,
  tipo text NOT NULL CHECK (tipo IN ('aporte','resgate')),
  valor numeric NOT NULL CHECK (valor > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.investimento_movimentacoes ENABLE ROW LEVEL SECURITY;
CREATE POLICY inv_mov_all_own ON public.investimento_movimentacoes FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_inv_mov_inv ON public.investimento_movimentacoes(investimento_id, created_at DESC);

-- META: aporte (saldo -> meta)
CREATE OR REPLACE FUNCTION public.meta_aportar(_meta_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  IF NOT EXISTS (SELECT 1 FROM metas WHERE id = _meta_id AND user_id = _uid) THEN
    RAISE EXCEPTION 'Meta não encontrada';
  END IF;
  UPDATE profiles SET saldo_atual = COALESCE(saldo_atual,0) - _valor, updated_at = now() WHERE id = _uid;
  UPDATE metas SET valor_atual = COALESCE(valor_atual,0) + _valor WHERE id = _meta_id;
  INSERT INTO meta_movimentacoes(user_id, meta_id, tipo, valor) VALUES (_uid, _meta_id, 'aporte', _valor);
END; $$;

-- META: resgate (meta -> saldo)
CREATE OR REPLACE FUNCTION public.meta_resgatar(_meta_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid; _atual numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_atual INTO _atual FROM metas WHERE id = _meta_id AND user_id = _uid;
  IF _atual IS NULL THEN RAISE EXCEPTION 'Meta não encontrada'; END IF;
  IF _valor > _atual THEN RAISE EXCEPTION 'Valor maior que o guardado na meta'; END IF;
  UPDATE metas SET valor_atual = _atual - _valor WHERE id = _meta_id;
  UPDATE profiles SET saldo_atual = COALESCE(saldo_atual,0) + _valor, updated_at = now() WHERE id = _uid;
  INSERT INTO meta_movimentacoes(user_id, meta_id, tipo, valor) VALUES (_uid, _meta_id, 'resgate', _valor);
END; $$;

-- INVESTIMENTO: aporte (saldo -> investimento; aumenta investido e atual)
CREATE OR REPLACE FUNCTION public.investimento_aportar(_inv_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid; _vi numeric; _va numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_investido, valor_atual INTO _vi, _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _vi IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  UPDATE profiles SET saldo_atual = COALESCE(saldo_atual,0) - _valor, updated_at = now() WHERE id = _uid;
  UPDATE investimentos
     SET valor_investido = _vi + _valor,
         valor_atual = _va + _valor,
         lucro = (_va + _valor) - (_vi + _valor),
         rentabilidade = CASE WHEN (_vi + _valor) > 0 THEN (((_va + _valor) - (_vi + _valor)) / (_vi + _valor)) * 100 ELSE 0 END
   WHERE id = _inv_id;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor) VALUES (_uid, _inv_id, 'aporte', _valor);
END; $$;

-- INVESTIMENTO: resgate (investimento -> saldo; reduz proporcionalmente o investido)
CREATE OR REPLACE FUNCTION public.investimento_resgatar(_inv_id uuid, _valor numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid; _vi numeric; _va numeric; _novo_va numeric; _novo_vi numeric;
BEGIN
  IF _valor IS NULL OR _valor <= 0 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
  _uid := auth.uid();
  IF _uid IS NULL THEN RAISE EXCEPTION 'Não autenticado'; END IF;
  SELECT valor_investido, valor_atual INTO _vi, _va FROM investimentos WHERE id = _inv_id AND user_id = _uid;
  IF _vi IS NULL THEN RAISE EXCEPTION 'Investimento não encontrado'; END IF;
  IF _valor > _va THEN RAISE EXCEPTION 'Valor maior que o disponível no investimento'; END IF;
  _novo_va := _va - _valor;
  _novo_vi := CASE WHEN _va > 0 THEN _vi * (_novo_va / _va) ELSE 0 END;
  UPDATE investimentos
     SET valor_atual = _novo_va,
         valor_investido = _novo_vi,
         lucro = _novo_va - _novo_vi,
         rentabilidade = CASE WHEN _novo_vi > 0 THEN ((_novo_va - _novo_vi) / _novo_vi) * 100 ELSE 0 END
   WHERE id = _inv_id;
  UPDATE profiles SET saldo_atual = COALESCE(saldo_atual,0) + _valor, updated_at = now() WHERE id = _uid;
  INSERT INTO investimento_movimentacoes(user_id, investimento_id, tipo, valor) VALUES (_uid, _inv_id, 'resgate', _valor);
END; $$;

REVOKE EXECUTE ON FUNCTION public.meta_aportar(uuid, numeric) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.meta_resgatar(uuid, numeric) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.meta_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.meta_resgatar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_aportar(uuid, numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.investimento_resgatar(uuid, numeric) TO authenticated;
