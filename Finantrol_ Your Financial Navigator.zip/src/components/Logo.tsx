export function Logo({ size = 36 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="rounded-xl gradient-primary flex items-center justify-center font-display font-bold shadow-glow"
        style={{ width: size, height: size, fontSize: size * 0.55 }}
      >
        <span style={{ color: "oklch(0.12 0.03 160)" }}>F</span>
      </div>
      <span className="font-display text-lg font-bold tracking-tight">
        FINAN<span className="text-primary">TROL</span>
      </span>
    </div>
  );
}
