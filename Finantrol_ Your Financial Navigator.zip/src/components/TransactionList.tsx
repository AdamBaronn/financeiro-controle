import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL, fmtDate } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui-bits";
import { Plus, Trash2, Pencil, X, Loader2, CreditCard, Wallet, Banknote, ArrowLeftRight, FileText, Smartphone } from "lucide-react";
import { toast } from "sonner";

type Tx = {
  id: string; titulo: string; valor: number; categoria: string; data: string;
  recorrente: boolean; parcela?: number;
  metodo_pagamento?: string; cartao_id?: string | null;
};
type Cartao = { id: string; nome: string; cor: string };

const CATS_R = ["Salário", "Freelance", "Investimentos", "Vendas", "Bônus", "Outros"];
const CATS_D = ["Alimentação", "Moradia", "Transporte", "Saúde", "Lazer", "Educação", "Compras", "Outros"];

const METODOS: { value: string; label: string; icon: any }[] = [
  { value: "dinheiro", label: "Dinheiro", icon: Banknote },
  { value: "pix", label: "Pix", icon: Smartphone },
  { value: "debito", label: "Débito", icon: Wallet },
  { value: "credito", label: "Crédito", icon: CreditCard },
  { value: "transferencia", label: "Transferência", icon: ArrowLeftRight },
  { value: "boleto", label: "Boleto", icon: FileText },
];

const metodoLabel = (m?: string) => METODOS.find((x) => x.value === m)?.label ?? "Dinheiro";

export function TransactionList({ table, title, isExpense }: { table: "receitas" | "despesas"; title: string; isExpense: boolean }) {
  const { user } = useAuth();
  const [items, setItems] = useState<Tx[]>([]);
  const [cartoes, setCartoes] = useState<Cartao[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Tx | null>(null);
  const [filter, setFilter] = useState("");
  const [cat, setCat] = useState("");

  const cats = isExpense ? CATS_D : CATS_R;

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from(table).select("*").order("data", { ascending: false });
    setItems((data ?? []) as any);
    if (isExpense) {
      const { data: c } = await supabase.from("cartoes").select("id,nome,cor").order("nome");
      setCartoes((c ?? []) as any);
    }
    setLoading(false);
  };
  useEffect(() => { if (user) load(); }, [user]);

  const handleDelete = async (id: string) => {
    if (!confirm("Excluir este item?")) return;
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Excluído"); load(); }
  };

  const handleSave = async (form: Tx) => {
    if (!user) return;
    const payload: any = {
      titulo: form.titulo, valor: form.valor, categoria: form.categoria, data: form.data,
      recorrente: form.recorrente, user_id: user.id,
    };
    if (isExpense) {
      payload.parcela = form.parcela ?? 1;
      payload.metodo_pagamento = form.metodo_pagamento ?? "dinheiro";
      payload.cartao_id = form.metodo_pagamento === "credito" ? (form.cartao_id ?? null) : null;
      if (payload.metodo_pagamento === "credito" && !payload.cartao_id) {
        toast.error("Selecione um cartão para pagamento no crédito");
        return;
      }
    }
    if (editing) {
      const { error } = await supabase.from(table).update(payload).eq("id", editing.id);
      if (error) { toast.error(error.message); return; }
      toast.success("Atualizado");
    } else {
      const { error } = await supabase.from(table).insert(payload);
      if (error) { toast.error(error.message); return; }
      toast.success("Adicionado");
    }
    setOpen(false); setEditing(null); load();
  };

  const filtered = items.filter((i) =>
    (!filter || i.titulo.toLowerCase().includes(filter.toLowerCase())) &&
    (!cat || i.categoria === cat)
  );
  const total = filtered.reduce((s, i) => s + Number(i.valor), 0);

  return (
    <div>
      <PageHeader
        title={title}
        subtitle={`Total filtrado: ${fmtBRL(total)}`}
        action={
          <button onClick={() => { setEditing(null); setOpen(true); }}
            className="gradient-primary text-primary-foreground rounded-xl px-4 py-2.5 font-medium shadow-glow flex items-center gap-2">
            <Plus className="w-4 h-4" /> Adicionar
          </button>
        }
      />

      <div className="glass rounded-2xl p-4 mb-4 grid sm:grid-cols-2 gap-3">
        <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Pesquisar..."
          className="bg-input rounded-xl px-4 py-2.5 outline-none focus:ring-2 ring-primary" />
        <select value={cat} onChange={(e) => setCat(e.target.value)}
          className="bg-input rounded-xl px-4 py-2.5 outline-none focus:ring-2 ring-primary">
          <option value="">Todas categorias</option>
          {cats.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : filtered.length === 0 ? (
        <EmptyState title="Nada por aqui ainda" desc="Comece adicionando seu primeiro lançamento." />
      ) : (
        <div className="glass rounded-2xl overflow-hidden divide-y divide-border/40">
          {filtered.map((i) => {
            const card = cartoes.find((c) => c.id === i.cartao_id);
            return (
              <div key={i.id} className="p-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-medium truncate">{i.titulo}</p>
                  <p className="text-xs text-muted-foreground">
                    {i.categoria} · {fmtDate(i.data)}
                    {i.recorrente ? " · Recorrente" : ""}
                    {isExpense && (i.parcela ?? 1) > 1 ? ` · ${i.parcela}x` : ""}
                    {isExpense ? ` · ${metodoLabel(i.metodo_pagamento)}` : ""}
                    {card ? ` · ${card.nome}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <p className={`font-semibold ${isExpense ? "text-destructive" : "text-success"}`}>{isExpense ? "-" : "+"} {fmtBRL(i.valor)}</p>
                  <button onClick={() => { setEditing(i); setOpen(true); }} className="p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(i.id)} className="p-2 rounded-lg hover:bg-destructive/20 text-destructive"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {open && (
        <Modal onClose={() => { setOpen(false); setEditing(null); }}>
          <TxForm editing={editing} cats={cats} isExpense={isExpense} cartoes={cartoes} onSave={handleSave} />
        </Modal>
      )}
    </div>
  );
}

export function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="glass-strong rounded-t-2xl sm:rounded-2xl p-6 max-w-md w-full relative animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-3 right-3 p-2 rounded-lg hover:bg-secondary z-10"><X className="w-4 h-4" /></button>
        {children}
      </div>
    </div>
  );
}

function TxForm({ editing, cats, isExpense, cartoes, onSave }: { editing: Tx | null; cats: string[]; isExpense: boolean; cartoes: Cartao[]; onSave: (t: Tx) => void | Promise<void> }) {
  const [form, setForm] = useState<Tx>({
    id: editing?.id ?? "",
    titulo: editing?.titulo ?? "",
    valor: Number(editing?.valor ?? 0),
    categoria: editing?.categoria ?? cats[0],
    data: editing?.data ?? new Date().toISOString().slice(0, 10),
    recorrente: editing?.recorrente ?? false,
    parcela: editing?.parcela ?? 1,
    metodo_pagamento: editing?.metodo_pagamento ?? "dinheiro",
    cartao_id: editing?.cartao_id ?? null,
  });
  const [loading, setLoading] = useState(false);
  const isCredito = form.metodo_pagamento === "credito";

  return (
    <form onSubmit={async (e) => { e.preventDefault(); setLoading(true); await onSave(form); setLoading(false); }} className="space-y-4">
      <h3 className="font-display text-xl font-bold">{editing ? "Editar" : "Adicionar"}</h3>
      <input required placeholder="Título" value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })}
        className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <input required type="number" step="0.01" min="0" placeholder="Valor" value={form.valor || ""}
        onChange={(e) => setForm({ ...form, valor: parseFloat(e.target.value) || 0 })}
        className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <select value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}
        className="w-full bg-input rounded-xl px-4 py-3 outline-none">
        {cats.map((c) => <option key={c} value={c}>{c}</option>)}
      </select>
      <input required type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })}
        className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />

      {isExpense && (
        <>
          <div>
            <p className="text-sm font-medium mb-2">Método de pagamento</p>
            <div className="grid grid-cols-3 gap-2">
              {METODOS.map((m) => {
                const Icon = m.icon;
                const active = form.metodo_pagamento === m.value;
                return (
                  <button key={m.value} type="button"
                    onClick={() => setForm({ ...form, metodo_pagamento: m.value, cartao_id: m.value === "credito" ? form.cartao_id : null, parcela: m.value === "credito" ? form.parcela : 1 })}
                    className={`flex flex-col items-center gap-1 py-3 rounded-xl text-xs font-medium transition ${active ? "gradient-primary text-primary-foreground shadow-glow" : "bg-input hover:bg-secondary"}`}>
                    <Icon className="w-4 h-4" /> {m.label}
                  </button>
                );
              })}
            </div>
          </div>

          {isCredito && (
            <>
              <select required value={form.cartao_id ?? ""} onChange={(e) => setForm({ ...form, cartao_id: e.target.value })}
                className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary">
                <option value="">Selecione um cartão</option>
                {cartoes.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
              </select>
              {cartoes.length === 0 && (
                <p className="text-xs text-muted-foreground">Nenhum cartão cadastrado. Adicione um em Cartões.</p>
              )}
              <input type="number" min="1" max="48" placeholder="Parcelas" value={form.parcela || 1}
                onChange={(e) => setForm({ ...form, parcela: parseInt(e.target.value) || 1 })}
                className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
              <p className="text-xs text-muted-foreground -mt-2">Será lançado na fatura do cartão e não sai do saldo.</p>
            </>
          )}
        </>
      )}

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={form.recorrente} onChange={(e) => setForm({ ...form, recorrente: e.target.checked })} />
        Recorrente
      </label>
      <button type="submit" disabled={loading} className="w-full gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60">
        {loading && <Loader2 className="w-4 h-4 animate-spin" />} Salvar
      </button>
    </form>
  );
}
