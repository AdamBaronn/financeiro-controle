import { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";

export function AuthShell({ title, subtitle, children, footer }: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="min-h-screen flex">
      {/* Left visual */}
      <div className="hidden lg:flex w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-30" />
        <div className="absolute inset-0" style={{
          background: "radial-gradient(ellipse at 30% 30%, oklch(0.78 0.18 155 / 0.4), transparent 60%)"
        }} />
        <div className="relative z-10 p-12 flex flex-col justify-between w-full">
          <Logo size={40} />
          <div>
            <h2 className="font-display text-4xl font-bold text-gradient leading-tight">
              Sua vida financeira,<br />em alta definição.
            </h2>
            <p className="mt-4 text-muted-foreground max-w-md">
              Acompanhe receitas, despesas, metas, cartões e investimentos com a elegância de uma fintech premium.
            </p>
          </div>
        </div>
      </div>

      {/* Right form */}
      <div className="flex-1 flex flex-col p-6 md:p-12">
        <div className="lg:hidden mb-8">
          <Link to="/"><Logo /></Link>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="w-full max-w-md">
            <h1 className="font-display text-3xl font-bold">{title}</h1>
            {subtitle && <p className="text-muted-foreground mt-2">{subtitle}</p>}
            <div className="mt-8">{children}</div>
            {footer && <div className="mt-6 text-sm text-center text-muted-foreground">{footer}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
