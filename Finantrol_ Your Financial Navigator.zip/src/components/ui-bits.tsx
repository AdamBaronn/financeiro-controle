import { ReactNode } from "react";

export function StatCard({
  label, value, sub, icon, accent = false,
}: { label: string; value: ReactNode; sub?: ReactNode; icon?: ReactNode; accent?: boolean }) {
  return (
    <div className={`rounded-2xl p-5 ${accent ? "gradient-primary text-primary-foreground shadow-glow" : "glass"}`}>
      <div className="flex items-center justify-between">
        <p className={`text-xs ${accent ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{label}</p>
        {icon}
      </div>
      <p className="text-2xl md:text-3xl font-display font-bold mt-2">{value}</p>
      {sub && <p className={`text-xs mt-1 ${accent ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{sub}</p>}
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-6 gap-3 flex-wrap">
      <div>
        <h2 className="font-display text-2xl md:text-3xl font-bold">{title}</h2>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="glass rounded-2xl p-12 text-center">
      <p className="font-semibold text-lg">{title}</p>
      {desc && <p className="text-sm text-muted-foreground mt-2">{desc}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
