export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      cartoes: {
        Row: {
          cor: string
          created_at: string
          fechamento: number
          id: string
          limite: number
          nome: string
          user_id: string
          vencimento: number
        }
        Insert: {
          cor?: string
          created_at?: string
          fechamento?: number
          id?: string
          limite?: number
          nome: string
          user_id: string
          vencimento?: number
        }
        Update: {
          cor?: string
          created_at?: string
          fechamento?: number
          id?: string
          limite?: number
          nome?: string
          user_id?: string
          vencimento?: number
        }
        Relationships: []
      }
      configuracoes: {
        Row: {
          id: string
          idioma: string
          moeda: string
          tema: string
          user_id: string
        }
        Insert: {
          id?: string
          idioma?: string
          moeda?: string
          tema?: string
          user_id: string
        }
        Update: {
          id?: string
          idioma?: string
          moeda?: string
          tema?: string
          user_id?: string
        }
        Relationships: []
      }
      despesas: {
        Row: {
          cartao_id: string | null
          categoria: string
          created_at: string
          data: string
          id: string
          metodo_pagamento: string
          parcela: number
          recorrente: boolean
          titulo: string
          user_id: string
          valor: number
        }
        Insert: {
          cartao_id?: string | null
          categoria?: string
          created_at?: string
          data?: string
          id?: string
          metodo_pagamento?: string
          parcela?: number
          recorrente?: boolean
          titulo: string
          user_id: string
          valor: number
        }
        Update: {
          cartao_id?: string | null
          categoria?: string
          created_at?: string
          data?: string
          id?: string
          metodo_pagamento?: string
          parcela?: number
          recorrente?: boolean
          titulo?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      fatura_itens: {
        Row: {
          created_at: string
          despesa_id: string
          fatura_id: string
          id: string
          parcela_atual: number
          parcela_total: number
          user_id: string
          valor: number
        }
        Insert: {
          created_at?: string
          despesa_id: string
          fatura_id: string
          id?: string
          parcela_atual?: number
          parcela_total?: number
          user_id: string
          valor: number
        }
        Update: {
          created_at?: string
          despesa_id?: string
          fatura_id?: string
          id?: string
          parcela_atual?: number
          parcela_total?: number
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "fatura_itens_despesa_id_fkey"
            columns: ["despesa_id"]
            isOneToOne: false
            referencedRelation: "despesas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fatura_itens_fatura_id_fkey"
            columns: ["fatura_id"]
            isOneToOne: false
            referencedRelation: "faturas"
            referencedColumns: ["id"]
          },
        ]
      }
      faturas: {
        Row: {
          cartao_id: string
          created_at: string
          id: string
          mes_referencia: string
          paga_em: string | null
          status: string
          user_id: string
          valor_total: number
          vencimento: string
        }
        Insert: {
          cartao_id: string
          created_at?: string
          id?: string
          mes_referencia: string
          paga_em?: string | null
          status?: string
          user_id: string
          valor_total?: number
          vencimento: string
        }
        Update: {
          cartao_id?: string
          created_at?: string
          id?: string
          mes_referencia?: string
          paga_em?: string | null
          status?: string
          user_id?: string
          valor_total?: number
          vencimento?: string
        }
        Relationships: []
      }
      investimento_movimentacoes: {
        Row: {
          created_at: string
          id: string
          investimento_id: string
          tipo: string
          user_id: string
          valor: number
        }
        Insert: {
          created_at?: string
          id?: string
          investimento_id: string
          tipo: string
          user_id: string
          valor: number
        }
        Update: {
          created_at?: string
          id?: string
          investimento_id?: string
          tipo?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "investimento_movimentacoes_investimento_id_fkey"
            columns: ["investimento_id"]
            isOneToOne: false
            referencedRelation: "investimentos"
            referencedColumns: ["id"]
          },
        ]
      }
      investimentos: {
        Row: {
          banco: string | null
          created_at: string
          data_inicio: string
          id: string
          lucro: number | null
          nome: string
          observacoes: string | null
          rentabilidade: number | null
          tipo: string
          user_id: string
          valor_atual: number
          valor_investido: number
        }
        Insert: {
          banco?: string | null
          created_at?: string
          data_inicio?: string
          id?: string
          lucro?: number | null
          nome: string
          observacoes?: string | null
          rentabilidade?: number | null
          tipo?: string
          user_id: string
          valor_atual: number
          valor_investido: number
        }
        Update: {
          banco?: string | null
          created_at?: string
          data_inicio?: string
          id?: string
          lucro?: number | null
          nome?: string
          observacoes?: string | null
          rentabilidade?: number | null
          tipo?: string
          user_id?: string
          valor_atual?: number
          valor_investido?: number
        }
        Relationships: []
      }
      meta_movimentacoes: {
        Row: {
          created_at: string
          id: string
          meta_id: string
          tipo: string
          user_id: string
          valor: number
        }
        Insert: {
          created_at?: string
          id?: string
          meta_id: string
          tipo: string
          user_id: string
          valor: number
        }
        Update: {
          created_at?: string
          id?: string
          meta_id?: string
          tipo?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "meta_movimentacoes_meta_id_fkey"
            columns: ["meta_id"]
            isOneToOne: false
            referencedRelation: "metas"
            referencedColumns: ["id"]
          },
        ]
      }
      metas: {
        Row: {
          created_at: string
          id: string
          prazo: string | null
          titulo: string
          user_id: string
          valor_atual: number
          valor_meta: number
        }
        Insert: {
          created_at?: string
          id?: string
          prazo?: string | null
          titulo: string
          user_id: string
          valor_atual?: number
          valor_meta: number
        }
        Update: {
          created_at?: string
          id?: string
          prazo?: string | null
          titulo?: string
          user_id?: string
          valor_atual?: number
          valor_meta?: number
        }
        Relationships: []
      }
      notificacoes: {
        Row: {
          created_at: string
          descricao: string | null
          id: string
          lida: boolean
          titulo: string
          user_id: string
        }
        Insert: {
          created_at?: string
          descricao?: string | null
          id?: string
          lida?: boolean
          titulo: string
          user_id: string
        }
        Update: {
          created_at?: string
          descricao?: string | null
          id?: string
          lida?: boolean
          titulo?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          id: string
          nome: string | null
          saldo_atual: number
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          id: string
          nome?: string | null
          saldo_atual?: number
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          id?: string
          nome?: string | null
          saldo_atual?: number
          updated_at?: string
        }
        Relationships: []
      }
      receitas: {
        Row: {
          categoria: string
          created_at: string
          data: string
          id: string
          recorrente: boolean
          titulo: string
          user_id: string
          valor: number
        }
        Insert: {
          categoria?: string
          created_at?: string
          data?: string
          id?: string
          recorrente?: boolean
          titulo: string
          user_id: string
          valor: number
        }
        Update: {
          categoria?: string
          created_at?: string
          data?: string
          id?: string
          recorrente?: boolean
          titulo?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      saldo_historico: {
        Row: {
          created_at: string
          id: string
          user_id: string
          valor_anterior: number
          valor_novo: number
        }
        Insert: {
          created_at?: string
          id?: string
          user_id: string
          valor_anterior: number
          valor_novo: number
        }
        Update: {
          created_at?: string
          id?: string
          user_id?: string
          valor_anterior?: number
          valor_novo?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      apply_saldo_delta: {
        Args: { _delta: number; _user_id: string }
        Returns: undefined
      }
      get_or_create_fatura: {
        Args: { _cartao_id: string; _data: string; _user_id: string }
        Returns: string
      }
      investimento_aportar: {
        Args: { _inv_id: string; _valor: number }
        Returns: undefined
      }
      investimento_comprar: {
        Args: { _inv_id: string; _valor: number }
        Returns: undefined
      }
      investimento_lucro: {
        Args: { _inv_id: string; _valor: number }
        Returns: undefined
      }
      investimento_reinvestir_lucro: {
        Args: { _inv_id: string; _valor: number }
        Returns: undefined
      }
      investimento_resgatar: {
        Args: { _inv_id: string; _valor: number }
        Returns: undefined
      }
      meta_aportar: {
        Args: { _meta_id: string; _valor: number }
        Returns: undefined
      }
      meta_resgatar: {
        Args: { _meta_id: string; _valor: number }
        Returns: undefined
      }
      pagar_fatura: { Args: { _fatura_id: string }; Returns: undefined }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
