import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AuthShell } from "@/components/AuthShell";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Mail } from "lucide-react";

export const Route = createFileRoute("/verify-email")({
  component: VerifyPage,
});

function VerifyPage() {
  const { user, emailConfirmed, signOut } = useAuth();
  const nav = useNavigate();

  useEffect(() => {
    if (emailConfirmed && user) nav({ to: "/dashboard" });
  }, [emailConfirmed, user, nav]);

  const resend = async () => {
    if (!user?.email) return;
    const { error } = await supabase.auth.resend({ type: "signup", email: user.email });
    if (error) toast.error(error.message);
    else toast.success("Email reenviado!");
  };

  return (
    <AuthShell title="Verifique seu email" subtitle="Enviamos um link de confirmação.">
      <div className="glass rounded-2xl p-8 text-center">
        <div className="w-16 h-16 rounded-2xl gradient-primary mx-auto flex items-center justify-center shadow-glow">
          <Mail className="w-8 h-8 text-primary-foreground" />
        </div>
        <p className="mt-6 text-sm text-muted-foreground">
          Enviamos um link para <strong className="text-foreground">{user?.email ?? "seu email"}</strong>.
          Clique no link para ativar sua conta e desbloquear o dashboard.
        </p>
        <div className="mt-6 flex flex-col gap-2">
          <button onClick={resend} className="gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow">
            Reenviar email
          </button>
          <button onClick={async () => { await signOut(); nav({ to: "/login" }); }} className="text-sm text-muted-foreground hover:text-foreground">
            Sair
          </button>
        </div>
      </div>
      <div className="mt-4 text-center text-xs text-muted-foreground">
        Não recebeu? Cheque a pasta de spam. Ou <Link to="/login" className="text-primary">entre novamente</Link>.
      </div>
    </AuthShell>
  );
}
