import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell } from "@/components/AuthShell";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/reset-password")({
  component: ResetPage,
});

function ResetPage() {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const nav = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) { toast.error("Mínimo 6 caracteres."); return; }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Senha redefinida!");
    nav({ to: "/dashboard" });
  };

  return (
    <AuthShell title="Nova senha" subtitle="Defina uma nova senha para sua conta.">
      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="text-sm font-medium">Nova senha</label>
          <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)}
            className="mt-1.5 w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
        </div>
        <button type="submit" disabled={loading}
          className="w-full gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60">
          {loading && <Loader2 className="w-4 h-4 animate-spin" />} Salvar nova senha
        </button>
      </form>
    </AuthShell>
  );
}
