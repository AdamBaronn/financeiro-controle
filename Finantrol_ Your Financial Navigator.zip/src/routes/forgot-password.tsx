import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell } from "@/components/AuthShell";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/forgot-password")({
  component: ForgotPage,
});

function ForgotPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setSent(true);
    toast.success("Email enviado!");
  };

  return (
    <AuthShell
      title="Recuperar senha"
      subtitle="Enviaremos um link para redefinir sua senha."
      footer={<Link to="/login" className="text-primary">Voltar ao login</Link>}
    >
      {sent ? (
        <div className="glass rounded-2xl p-6 text-center text-sm text-muted-foreground">
          Se o email existir, você receberá um link para redefinir sua senha em instantes.
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              className="mt-1.5 w-full glass rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" placeholder="voce@email.com" />
          </div>
          <button type="submit" disabled={loading}
            className="w-full gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />} Enviar link
          </button>
        </form>
      )}
    </AuthShell>
  );
}
