import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui-bits";
import { Modal } from "@/components/TransactionList";
import { Plus, Trash2, Pencil, Loader2, CreditCard } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/cartoes")({ component: CartoesPage });

type Cartao = { id: string; nome: string; limite: number; fechamento: number; vencimento: number; cor: string };

function CartoesPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Cartao[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Cartao | null>(null);

  const load = async () => { setLoading(true); const { data } = await supabase.from("cartoes").select("*").order("created_at", { ascending: false }); setItems((data ?? []) as any); setLoading(false); };
  useEffect(() => { if (user) load(); }, [user]);

  const del = async (id: string) => { if (!confirm("Excluir cartão?")) return; const { error } = await supabase.from("cartoes").delete().eq("id", id); if (error) toast.error(error.message); else { toast.success("Excluído"); load(); } };

  return (
    <div>
      <PageHeader title="Cartões" subtitle="Gerencie seus cartões e faturas."
        action={<button onClick={() => { setEditing(null); setOpen(true); }} className="gradient-primary text-primary-foreground rounded-xl px-4 py-2.5 font-medium shadow-glow flex items-center gap-2"><Plus className="w-4 h-4" /> Novo cartão</button>} />
      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div> :
        items.length === 0 ? <EmptyState title="Nenhum cartão cadastrado" /> :
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((c) => (
            <div key={c.id} className="relative rounded-2xl p-5 text-white overflow-hidden shadow-card aspect-[1.6/1] flex flex-col justify-between" style={{ background: `linear-gradient(135deg, ${c.cor}, oklch(0.20 0.025 160))` }}>
              <div className="absolute top-3 right-3 flex gap-1">
                <button onClick={() => { setEditing(c); setOpen(true); }} className="p-1.5 rounded-lg bg-white/15 hover:bg-white/25"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => del(c.id)} className="p-1.5 rounded-lg bg-white/15 hover:bg-white/25"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
              <CreditCard className="w-7 h-7 opacity-80" />
              <div>
                <p className="text-xs opacity-80">Limite</p>
                <p className="text-2xl font-display font-bold">{fmtBRL(c.limite)}</p>
                <p className="text-sm mt-2 font-medium">{c.nome}</p>
                <p className="text-xs opacity-80 mt-1">Fecha dia {c.fechamento} · Vence dia {c.vencimento}</p>
              </div>
            </div>
          ))}
        </div>
      }
      {open && <Modal onClose={() => { setOpen(false); setEditing(null); }}>
        <CartaoForm editing={editing} onSaved={() => { setOpen(false); setEditing(null); load(); }} />
      </Modal>}
    </div>
  );
}

function CartaoForm({ editing, onSaved }: { editing: Cartao | null; onSaved: () => void }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    nome: editing?.nome ?? "",
    limite: Number(editing?.limite ?? 0),
    fechamento: editing?.fechamento ?? 1,
    vencimento: editing?.vencimento ?? 10,
    cor: editing?.cor ?? "#10b981",
  });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); if (!user) return; setLoading(true);
    const payload: any = { ...form, user_id: user.id };
    const { error } = editing ? await supabase.from("cartoes").update(payload).eq("id", editing.id) : await supabase.from("cartoes").insert(payload);
    setLoading(false);
    if (error) toast.error(error.message); else { toast.success("Salvo"); onSaved(); }
  };

  const cores = ["#10b981", "#3b82f6", "#8b5cf6", "#ef4444", "#f59e0b", "#0ea5e9"];

  return (
    <form onSubmit={submit} className="space-y-4">
      <h3 className="font-display text-xl font-bold">{editing ? "Editar cartão" : "Novo cartão"}</h3>
      <input required placeholder="Nome do cartão" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <input required type="number" step="0.01" placeholder="Limite" value={form.limite || ""} onChange={(e) => setForm({ ...form, limite: parseFloat(e.target.value) || 0 })} className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <div className="grid grid-cols-2 gap-3">
        <input required type="number" min="1" max="31" placeholder="Fechamento" value={form.fechamento} onChange={(e) => setForm({ ...form, fechamento: parseInt(e.target.value) || 1 })} className="bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
        <input required type="number" min="1" max="31" placeholder="Vencimento" value={form.vencimento} onChange={(e) => setForm({ ...form, vencimento: parseInt(e.target.value) || 1 })} className="bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      </div>
      <div>
        <p className="text-sm font-medium mb-2">Cor</p>
        <div className="flex gap-2">
          {cores.map((c) => (
            <button key={c} type="button" onClick={() => setForm({ ...form, cor: c })}
              className={`w-9 h-9 rounded-full ${form.cor === c ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}
              style={{ background: c }} />
          ))}
        </div>
      </div>
      <button type="submit" disabled={loading} className="w-full gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60">
        {loading && <Loader2 className="w-4 h-4 animate-spin" />} Salvar
      </button>
    </form>
  );
}
