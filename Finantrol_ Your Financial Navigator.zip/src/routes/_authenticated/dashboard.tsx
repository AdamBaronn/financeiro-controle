import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL, monthKey, monthLabel } from "@/lib/format";
import { StatCard } from "@/components/ui-bits";
import {
  AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, Legend,
} from "recharts";
import { Wallet, TrendingUp, TrendingDown, PiggyBank, Pencil, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

type Profile = { saldo_atual: number };
type Receita = { id: string; titulo: string; valor: number; categoria: string; data: string };
type Despesa = { id: string; titulo: string; valor: number; categoria: string; data: string };
type Investimento = { lucro: number; valor_atual: number };

function DashboardPage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [receitas, setReceitas] = useState<Receita[]>([]);
  const [despesas, setDespesas] = useState<Despesa[]>([]);
  const [investimentos, setInvestimentos] = useState<Investimento[]>([]);
  const [loading, setLoading] = useState(true);
  const [editSaldo, setEditSaldo] = useState(false);
  const [novoSaldo, setNovoSaldo] = useState("");
  const [savingSaldo, setSavingSaldo] = useState(false);

  const load = async () => {
    if (!user) return;
    setLoading(true);
    const [p, r, d, i] = await Promise.all([
      supabase.from("profiles").select("saldo_atual").eq("id", user.id).single(),
      supabase.from("receitas").select("id,titulo,valor,categoria,data").order("data", { ascending: false }),
      supabase.from("despesas").select("id,titulo,valor,categoria,data").order("data", { ascending: false }),
      supabase.from("investimentos").select("lucro,valor_atual"),
    ]);
    setProfile(p.data as any);
    setReceitas((r.data ?? []) as any);
    setDespesas((d.data ?? []) as any);
    setInvestimentos((i.data ?? []) as any);
    setLoading(false);
  };

  useEffect(() => { load(); }, [user]);

  // Realtime: recarrega quando profile/receitas/despesas mudam (trigger atualiza saldo automaticamente)
  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel(`dash-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles", filter: `id=eq.${user.id}` }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "receitas", filter: `user_id=eq.${user.id}` }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "despesas", filter: `user_id=eq.${user.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const now = new Date();
  const thisMonth = monthKey(now);

  const recMes = receitas.filter((x) => monthKey(x.data) === thisMonth).reduce((s, x) => s + Number(x.valor), 0);
  const despMes = despesas.filter((x) => monthKey(x.data) === thisMonth).reduce((s, x) => s + Number(x.valor), 0);
  const economia = recMes - despMes;
  const totalInv = investimentos.reduce((s, x) => s + Number(x.valor_atual), 0);
  const lucroInv = investimentos.reduce((s, x) => s + Number(x.lucro), 0);
  const patrimonio = Number(profile?.saldo_atual ?? 0) + totalInv;

  const chartData = useMemo(() => {
    const months: string[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push(monthKey(d));
    }
    return months.map((m) => ({
      mes: monthLabel(m),
      receitas: receitas.filter((x) => monthKey(x.data) === m).reduce((s, x) => s + Number(x.valor), 0),
      despesas: despesas.filter((x) => monthKey(x.data) === m).reduce((s, x) => s + Number(x.valor), 0),
    }));
  }, [receitas, despesas]);

  const categoriaData = useMemo(() => {
    const map = new Map<string, number>();
    despesas.filter((x) => monthKey(x.data) === thisMonth).forEach((x) => {
      map.set(x.categoria, (map.get(x.categoria) ?? 0) + Number(x.valor));
    });
    return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
  }, [despesas]);

  const ultimas = [
    ...receitas.slice(0, 5).map((r) => ({ ...r, tipo: "receita" as const })),
    ...despesas.slice(0, 5).map((d) => ({ ...d, tipo: "despesa" as const })),
  ].sort((a, b) => +new Date(b.data) - +new Date(a.data)).slice(0, 6);

  const saveSaldo = async () => {
    if (!user) return;
    const v = parseFloat(novoSaldo.replace(",", "."));
    if (isNaN(v)) { toast.error("Valor inválido"); return; }
    setSavingSaldo(true);
    const prev = Number(profile?.saldo_atual ?? 0);
    const { error } = await supabase.from("profiles").update({ saldo_atual: v, updated_at: new Date().toISOString() }).eq("id", user.id);
    if (!error) {
      await supabase.from("saldo_historico").insert({ user_id: user.id, valor_anterior: prev, valor_novo: v });
      toast.success("Saldo atualizado");
      setEditSaldo(false);
      setNovoSaldo("");
      load();
    } else toast.error(error.message);
    setSavingSaldo(false);
  };

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;

  const COLORS = ["oklch(0.78 0.18 155)", "oklch(0.70 0.15 200)", "oklch(0.80 0.17 75)", "oklch(0.65 0.22 25)", "oklch(0.72 0.15 290)", "oklch(0.65 0.18 50)"];

  return (
    <div className="space-y-6">
      {/* Saldo destaque */}
      <div className="gradient-primary rounded-3xl p-6 md:p-8 shadow-glow text-primary-foreground relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-white/10 blur-3xl pointer-events-none" />
        <p className="text-sm opacity-80 relative">Saldo atual</p>
        <div className="flex items-center gap-3 mt-2 flex-wrap">
          <p className="text-4xl md:text-5xl font-display font-bold break-all">{fmtBRL(profile?.saldo_atual)}</p>
          <button
            type="button"
            onClick={() => { setNovoSaldo(String(profile?.saldo_atual ?? 0)); setEditSaldo(true); }}
            className="rounded-xl bg-white/20 active:bg-white/35 hover:bg-white/30 px-4 py-2.5 text-sm font-medium flex items-center gap-1.5 touch-manipulation select-none"
          >
            <Pencil className="w-4 h-4" /> Editar
          </button>
        </div>
        <p className="text-xs opacity-80 mt-2">Patrimônio total: <strong>{fmtBRL(patrimonio)}</strong></p>
      </div>

      {editSaldo && (
        <div
          className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm"
          onClick={() => !savingSaldo && setEditSaldo(false)}
        >
          <div
            className="glass-strong w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl p-6 animate-in slide-in-from-bottom sm:zoom-in-95 fade-in"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-xl font-bold mb-1">Editar saldo</h3>
            <p className="text-xs text-muted-foreground mb-4">Saldo atual: {fmtBRL(profile?.saldo_atual)}</p>
            <input
              type="text"
              inputMode="decimal"
              autoFocus
              value={novoSaldo}
              onChange={(e) => setNovoSaldo(e.target.value.replace(/[^0-9.,-]/g, ""))}
              placeholder="0,00"
              className="w-full bg-input rounded-xl px-4 py-4 text-2xl font-bold outline-none focus:ring-2 ring-primary mb-4"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setEditSaldo(false)}
                disabled={savingSaldo}
                className="flex-1 rounded-xl bg-secondary px-4 py-3 font-medium touch-manipulation"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={saveSaldo}
                disabled={savingSaldo}
                className="flex-1 gradient-primary text-primary-foreground rounded-xl px-4 py-3 font-semibold shadow-glow flex items-center justify-center gap-2 touch-manipulation disabled:opacity-60"
              >
                {savingSaldo ? <Loader2 className="w-4 h-4 animate-spin" /> : "Salvar"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Receitas do mês" value={fmtBRL(recMes)} icon={<TrendingUp className="w-4 h-4 text-success" />} />
        <StatCard label="Despesas do mês" value={fmtBRL(despMes)} icon={<TrendingDown className="w-4 h-4 text-destructive" />} />
        <StatCard label="Economia mensal" value={fmtBRL(economia)} sub={economia >= 0 ? "Positivo" : "Negativo"} icon={<PiggyBank className="w-4 h-4 text-primary" />} />
        <StatCard label="Lucro investimentos" value={fmtBRL(lucroInv)} sub={`Total: ${fmtBRL(totalInv)}`} icon={<Wallet className="w-4 h-4 text-chart-2" />} />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-5 lg:col-span-2">
          <h3 className="font-semibold mb-4">Fluxo dos últimos 6 meses</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="cr" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.78 0.18 155)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="oklch(0.78 0.18 155)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="cd" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.65 0.22 25)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="oklch(0.65 0.22 25)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="mes" stroke="oklch(0.6 0.02 155)" fontSize={12} />
                <YAxis stroke="oklch(0.6 0.02 155)" fontSize={12} />
                <Tooltip
                  contentStyle={{ background: "oklch(0.20 0.025 160)", border: "1px solid oklch(0.32 0.025 160)", borderRadius: 12 }}
                  formatter={(v: any) => fmtBRL(v)}
                />
                <Area type="monotone" dataKey="receitas" stroke="oklch(0.78 0.18 155)" fill="url(#cr)" strokeWidth={2} />
                <Area type="monotone" dataKey="despesas" stroke="oklch(0.65 0.22 25)" fill="url(#cd)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <h3 className="font-semibold mb-4">Despesas por categoria</h3>
          {categoriaData.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-12">Sem despesas neste mês.</p>
          ) : (
            <div className="h-72">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={categoriaData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={3}>
                    {categoriaData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v: any) => fmtBRL(v)} contentStyle={{ background: "oklch(0.20 0.025 160)", border: "1px solid oklch(0.32 0.025 160)", borderRadius: 12 }} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Últimas transações */}
      <div className="glass rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Últimas transações</h3>
          <Link to="/receitas" className="text-xs text-primary">Ver todas</Link>
        </div>
        {ultimas.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Nenhuma transação ainda. Comece adicionando uma receita ou despesa.</p>
        ) : (
          <div className="divide-y divide-border/40">
            {ultimas.map((t) => (
              <div key={`${t.tipo}-${t.id}`} className="py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${t.tipo === "receita" ? "bg-success/15" : "bg-destructive/15"}`}>
                    {t.tipo === "receita" ? <TrendingUp className="w-4 h-4 text-success" /> : <TrendingDown className="w-4 h-4 text-destructive" />}
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium truncate">{t.titulo}</p>
                    <p className="text-xs text-muted-foreground">{t.categoria} · {new Date(t.data).toLocaleDateString("pt-BR")}</p>
                  </div>
                </div>
                <p className={`font-semibold ${t.tipo === "receita" ? "text-success" : "text-destructive"}`}>
                  {t.tipo === "receita" ? "+" : "-"} {fmtBRL(t.valor)}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
