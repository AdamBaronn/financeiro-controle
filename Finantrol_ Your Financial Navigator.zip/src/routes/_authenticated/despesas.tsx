import { createFileRoute } from "@tanstack/react-router";
import { TransactionList } from "@/components/TransactionList";
export const Route = createFileRoute("/_authenticated/despesas")({
  component: () => <TransactionList table="despesas" title="Despesas" isExpense={true} />,
});
