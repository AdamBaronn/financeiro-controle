import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { PageHeader } from "@/components/ui-bits";
import { Loader2, Upload, LogOut } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/configuracoes")({ component: ConfigPage });

function ConfigPage() {
  const { user, signOut } = useAuth();
  const nav = useNavigate();
  const [nome, setNome] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newPass, setNewPass] = useState("");

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from("profiles").select("nome,avatar_url").eq("id", user.id).single();
      if (data) { setNome(data.nome ?? ""); setAvatarUrl(data.avatar_url); }
      setLoading(false);
    })();
  }, [user]);

  const saveProfile = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ nome, updated_at: new Date().toISOString() }).eq("id", user.id);
    setSaving(false);
    if (error) toast.error(error.message); else toast.success("Perfil salvo");
  };

  const uploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file || !user) return;
    const ext = file.name.split(".").pop();
    const path = `${user.id}/avatar.${ext}`;
    const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (error) { toast.error(error.message); return; }
    const { data } = supabase.storage.from("avatars").createSignedUrl ? await supabase.storage.from("avatars").createSignedUrl(path, 60 * 60 * 24 * 365) : { data: { signedUrl: "" } };
    const url = data?.signedUrl ?? "";
    await supabase.from("profiles").update({ avatar_url: url }).eq("id", user.id);
    setAvatarUrl(url);
    toast.success("Avatar atualizado");
  };

  const changePass = async () => {
    if (newPass.length < 6) { toast.error("Mínimo 6 caracteres"); return; }
    const { error } = await supabase.auth.updateUser({ password: newPass });
    if (error) toast.error(error.message); else { toast.success("Senha alterada"); setNewPass(""); }
  };

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div>
      <PageHeader title="Configurações" subtitle="Gerencie sua conta e preferências." />
      <div className="space-y-4 max-w-2xl">
        <div className="glass rounded-2xl p-6">
          <h3 className="font-semibold mb-4">Perfil</h3>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center text-2xl font-bold text-primary-foreground overflow-hidden">
              {avatarUrl ? <img src={avatarUrl} alt="" className="w-full h-full object-cover" /> : (nome || user?.email || "U").charAt(0).toUpperCase()}
            </div>
            <label className="glass rounded-xl px-4 py-2.5 text-sm cursor-pointer flex items-center gap-2 hover:bg-secondary/50">
              <Upload className="w-4 h-4" /> Trocar foto
              <input type="file" accept="image/*" onChange={uploadAvatar} className="hidden" />
            </label>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium">Nome</label>
              <input value={nome} onChange={(e) => setNome(e.target.value)} className="mt-1.5 w-full bg-input rounded-xl px-4 py-2.5 outline-none focus:ring-2 ring-primary" />
            </div>
            <div>
              <label className="text-sm font-medium">Email</label>
              <input value={user?.email ?? ""} disabled className="mt-1.5 w-full bg-input rounded-xl px-4 py-2.5 opacity-60" />
            </div>
            <button onClick={saveProfile} disabled={saving} className="gradient-primary text-primary-foreground rounded-xl px-5 py-2.5 font-medium shadow-glow flex items-center gap-2">
              {saving && <Loader2 className="w-4 h-4 animate-spin" />} Salvar
            </button>
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <h3 className="font-semibold mb-4">Alterar senha</h3>
          <div className="flex gap-2 flex-wrap">
            <input type="password" placeholder="Nova senha" value={newPass} onChange={(e) => setNewPass(e.target.value)} className="flex-1 bg-input rounded-xl px-4 py-2.5 outline-none focus:ring-2 ring-primary min-w-[200px]" />
            <button onClick={changePass} className="gradient-primary text-primary-foreground rounded-xl px-5 py-2.5 font-medium shadow-glow">Atualizar</button>
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <h3 className="font-semibold mb-1">Sessão</h3>
          <p className="text-sm text-muted-foreground mb-4">Encerre sua sessão neste dispositivo.</p>
          <button onClick={async () => { await signOut(); nav({ to: "/" }); }} className="bg-destructive/20 text-destructive rounded-xl px-5 py-2.5 font-medium flex items-center gap-2">
            <LogOut className="w-4 h-4" /> Sair
          </button>
        </div>
      </div>
    </div>
  );
}
