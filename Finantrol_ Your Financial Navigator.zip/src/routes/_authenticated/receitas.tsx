import { createFileRoute } from "@tanstack/react-router";
import { TransactionList } from "@/components/TransactionList";
export const Route = createFileRoute("/_authenticated/receitas")({
  component: () => <TransactionList table="receitas" title="Receitas" isExpense={false} />,
});
