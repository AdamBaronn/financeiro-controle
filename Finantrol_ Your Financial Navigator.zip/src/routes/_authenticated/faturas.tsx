import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL, fmtDate } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui-bits";
import { Modal } from "@/components/TransactionList";
import { Loader2, Receipt, ChevronRight, CheckCircle2, Wallet } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/faturas")({ component: FaturasPage });

type Cartao = { id: string; nome: string; cor: string };
type Fatura = {
  id: string; cartao_id: string; mes_referencia: string; vencimento: string;
  valor_total: number; status: "aberta" | "paga"; paga_em: string | null;
};
type Item = {
  id: string; valor: number; parcela_atual: number; parcela_total: number;
  despesa: { titulo: string; categoria: string; data: string } | null;
};

function FaturasPage() {
  const { user } = useAuth();
  const [faturas, setFaturas] = useState<Fatura[]>([]);
  const [cartoes, setCartoes] = useState<Cartao[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtro, setFiltro] = useState<"todas" | "abertas" | "pagas">("abertas");
  const [detail, setDetail] = useState<Fatura | null>(null);

  const load = async () => {
    setLoading(true);
    const [{ data: f }, { data: c }] = await Promise.all([
      supabase.from("faturas").select("*").order("vencimento", { ascending: false }),
      supabase.from("cartoes").select("id,nome,cor"),
    ]);
    setFaturas((f ?? []) as any);
    setCartoes((c ?? []) as any);
    setLoading(false);
  };
  useEffect(() => { if (user) load(); }, [user]);

  const pagar = async (f: Fatura) => {
    if (!confirm(`Pagar fatura de ${fmtBRL(f.valor_total)}? O valor será debitado do seu saldo.`)) return;
    const { error } = await (supabase as any).rpc("pagar_fatura", { _fatura_id: f.id });
    if (error) toast.error(error.message);
    else { toast.success("Fatura paga"); load(); }
  };

  const filtradas = faturas.filter((f) =>
    filtro === "todas" ? true : filtro === "abertas" ? f.status === "aberta" : f.status === "paga"
  );

  const totalAberto = faturas.filter((f) => f.status === "aberta").reduce((s, f) => s + Number(f.valor_total), 0);

  return (
    <div>
      <PageHeader title="Faturas" subtitle={`Total em aberto: ${fmtBRL(totalAberto)}`} />

      <div className="glass rounded-2xl p-2 mb-4 inline-flex gap-1">
        {(["abertas", "pagas", "todas"] as const).map((f) => (
          <button key={f} onClick={() => setFiltro(f)}
            className={`px-4 py-2 rounded-xl text-sm font-medium capitalize transition ${filtro === f ? "gradient-primary text-primary-foreground shadow-glow" : "hover:bg-secondary"}`}>
            {f}
          </button>
        ))}
      </div>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div> :
        filtradas.length === 0 ? <EmptyState title="Nenhuma fatura" desc="Suas compras no crédito aparecerão aqui agrupadas por mês." /> :
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtradas.map((f) => {
            const card = cartoes.find((c) => c.id === f.cartao_id);
            const paga = f.status === "paga";
            return (
              <div key={f.id} className="glass rounded-2xl p-5 flex flex-col gap-3 hover:shadow-card transition">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: card?.cor ?? "#10b981" }}>
                    <Receipt className="w-5 h-5 text-white" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold truncate">{card?.nome ?? "Cartão"}</p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {new Date(f.mes_referencia).toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
                    </p>
                  </div>
                  {paga && <span className="text-xs px-2 py-1 rounded-lg bg-success/15 text-success flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Paga</span>}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="text-2xl font-display font-bold">{fmtBRL(f.valor_total)}</p>
                  <p className="text-xs text-muted-foreground mt-1">Vence em {fmtDate(f.vencimento)}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setDetail(f)} className="flex-1 bg-secondary hover:bg-secondary/70 rounded-xl py-2 text-sm font-medium flex items-center justify-center gap-1">
                    Detalhes <ChevronRight className="w-4 h-4" />
                  </button>
                  {!paga && Number(f.valor_total) > 0 && (
                    <button onClick={() => pagar(f)} className="flex-1 gradient-primary text-primary-foreground rounded-xl py-2 text-sm font-semibold shadow-glow flex items-center justify-center gap-1">
                      <Wallet className="w-4 h-4" /> Pagar
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      }

      {detail && (
        <Modal onClose={() => setDetail(null)}>
          <FaturaDetail fatura={detail} cartao={cartoes.find((c) => c.id === detail.cartao_id)} />
        </Modal>
      )}
    </div>
  );
}

function FaturaDetail({ fatura, cartao }: { fatura: Fatura; cartao?: Cartao }) {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("fatura_itens")
        .select("id,valor,parcela_atual,parcela_total,despesa:despesas(titulo,categoria,data)")
        .eq("fatura_id", fatura.id)
        .order("created_at");
      setItems((data ?? []) as any);
      setLoading(false);
    })();
  }, [fatura.id]);

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-display text-xl font-bold">{cartao?.nome ?? "Fatura"}</h3>
        <p className="text-sm text-muted-foreground capitalize">
          {new Date(fatura.mes_referencia).toLocaleDateString("pt-BR", { month: "long", year: "numeric" })} · Vence {fmtDate(fatura.vencimento)}
        </p>
        <p className="text-3xl font-display font-bold mt-2">{fmtBRL(fatura.valor_total)}</p>
      </div>
      {loading ? <div className="flex justify-center py-6"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div> :
        items.length === 0 ? <p className="text-sm text-muted-foreground">Sem lançamentos.</p> :
        <div className="divide-y divide-border/40 max-h-80 overflow-y-auto">
          {items.map((it) => (
            <div key={it.id} className="py-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{it.despesa?.titulo ?? "Lançamento"}</p>
                <p className="text-xs text-muted-foreground">
                  {it.despesa?.categoria}
                  {it.parcela_total > 1 ? ` · ${it.parcela_atual}/${it.parcela_total}` : ""}
                  {it.despesa?.data ? ` · ${fmtDate(it.despesa.data)}` : ""}
                </p>
              </div>
              <p className="text-sm font-semibold">{fmtBRL(it.valor)}</p>
            </div>
          ))}
        </div>
      }
    </div>
  );
}
