import { createFileRoute, Outlet, useNavigate, Link, useLocation } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Logo } from "@/components/Logo";
import {
  LayoutDashboard, TrendingUp, TrendingDown, Target, CreditCard, LineChart,
  FileBarChart, Settings, LogOut, Menu, X, Bell, Receipt
} from "lucide-react";

export const Route = createFileRoute("/_authenticated")({
  component: AuthenticatedLayout,
});

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/receitas", label: "Receitas", icon: TrendingUp },
  { to: "/despesas", label: "Despesas", icon: TrendingDown },
  { to: "/metas", label: "Metas", icon: Target },
  { to: "/cartoes", label: "Cartões", icon: CreditCard },
  { to: "/faturas", label: "Faturas", icon: Receipt },
  { to: "/investimentos", label: "Investimentos", icon: LineChart },
  { to: "/relatorios", label: "Relatórios", icon: FileBarChart },
  { to: "/configuracoes", label: "Configurações", icon: Settings },
] as const;

function AuthenticatedLayout() {
  const { user, loading, emailConfirmed, signOut } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => { setOpen(false); }, [loc.pathname]);

  useEffect(() => {
    if (loading) return;
    if (!user) nav({ to: "/login" });
    else if (!emailConfirmed) nav({ to: "/verify-email" });
  }, [user, emailConfirmed, loading, nav]);

  if (loading || !user || !emailConfirmed) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Sidebar desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-sidebar border-r border-sidebar-border p-5 sticky top-0 h-screen">
        <Link to="/dashboard"><Logo /></Link>
        <nav className="mt-10 flex-1 space-y-1">
          {NAV.map((item) => {
            const active = loc.pathname.startsWith(item.to);
            return (
              <Link key={item.to} to={item.to}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm transition-all ${
                  active ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-glow" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                }`}>
                <item.icon className="w-4 h-4" />{item.label}
              </Link>
            );
          })}
        </nav>
        <button onClick={async () => { await signOut(); nav({ to: "/" }); }}
          className="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm text-sidebar-foreground/70 hover:bg-destructive/20 hover:text-destructive transition">
          <LogOut className="w-4 h-4" /> Sair
        </button>
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-72 bg-sidebar p-5 flex flex-col">
            <div className="flex items-center justify-between">
              <Logo />
              <button onClick={() => setOpen(false)} className="p-2"><X className="w-5 h-5" /></button>
            </div>
            <nav className="mt-8 flex-1 space-y-1">
              {NAV.map((item) => {
                const active = loc.pathname.startsWith(item.to);
                return (
                  <Link key={item.to} to={item.to}
                    className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm ${active ? "bg-sidebar-accent" : "text-sidebar-foreground/70"}`}>
                    <item.icon className="w-4 h-4" />{item.label}
                  </Link>
                );
              })}
            </nav>
            <button onClick={async () => { await signOut(); nav({ to: "/" }); }}
              className="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm text-destructive">
              <LogOut className="w-4 h-4" /> Sair
            </button>
          </aside>
        </div>
      )}

      {/* Main */}
      <main className="flex-1 min-w-0 flex flex-col">
        {/* Topbar */}
        <div className="sticky top-0 z-30 glass border-b border-border/40 px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setOpen(true)} className="lg:hidden p-2"><Menu className="w-5 h-5" /></button>
            <h1 className="font-display text-lg font-semibold capitalize">
              {NAV.find((n) => loc.pathname.startsWith(n.to))?.label ?? "FINANTROL"}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/configuracoes" className="p-2 rounded-xl hover:bg-secondary"><Bell className="w-5 h-5" /></Link>
            <Link to="/configuracoes" className="w-9 h-9 rounded-full gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
              {(user.user_metadata?.nome ?? user.email ?? "U").charAt(0).toUpperCase()}
            </Link>
          </div>
        </div>
        <div className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
