import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL, fmtDate } from "@/lib/format";
import { PageHeader } from "@/components/ui-bits";
import { Download, FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/relatorios")({ component: Relatorios });

function Relatorios() {
  const { user } = useAuth();
  const [receitas, setReceitas] = useState<any[]>([]);
  const [despesas, setDespesas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const [r, d] = await Promise.all([
        supabase.from("receitas").select("*").order("data", { ascending: false }),
        supabase.from("despesas").select("*").order("data", { ascending: false }),
      ]);
      setReceitas(r.data ?? []); setDespesas(d.data ?? []); setLoading(false);
    })();
  }, [user]);

  const exportCSV = () => {
    const rows = [
      ["Tipo", "Título", "Valor", "Categoria", "Data"],
      ...receitas.map((r) => ["Receita", r.titulo, r.valor, r.categoria, r.data]),
      ...despesas.map((d) => ["Despesa", d.titulo, d.valor, d.categoria, d.data]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `finantrol-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV exportado");
  };

  const exportPDF = () => {
    const esc = (s: unknown) =>
      String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>FINANTROL - Relatório</title>
      <style>body{font-family:Inter,sans-serif;padding:32px;color:#111}h1{color:#10b981}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{padding:8px;border-bottom:1px solid #eee;text-align:left;font-size:13px}th{background:#f5f5f5}</style>
    </head><body>
      <h1>FINANTROL — Relatório Financeiro</h1>
      <p>Gerado em ${esc(new Date().toLocaleString("pt-BR"))}</p>
      <h2>Receitas</h2>
      <table><thead><tr><th>Data</th><th>Título</th><th>Categoria</th><th>Valor</th></tr></thead><tbody>
        ${receitas.map((r) => `<tr><td>${esc(fmtDate(r.data))}</td><td>${esc(r.titulo)}</td><td>${esc(r.categoria)}</td><td>${esc(fmtBRL(r.valor))}</td></tr>`).join("")}
      </tbody></table>
      <h2>Despesas</h2>
      <table><thead><tr><th>Data</th><th>Título</th><th>Categoria</th><th>Valor</th></tr></thead><tbody>
        ${despesas.map((d) => `<tr><td>${esc(fmtDate(d.data))}</td><td>${esc(d.titulo)}</td><td>${esc(d.categoria)}</td><td>${esc(fmtBRL(d.valor))}</td></tr>`).join("")}
      </tbody></table>
    </body></html>`;
    const w = window.open("", "_blank");
    if (w) { w.document.write(html); w.document.close(); setTimeout(() => w.print(), 400); }
  };

  if (loading) return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div>
      <PageHeader title="Relatórios" subtitle="Exporte e analise suas finanças." />
      <div className="grid sm:grid-cols-2 gap-4">
        <button onClick={exportCSV} className="glass rounded-2xl p-6 text-left hover:shadow-glow transition">
          <Download className="w-8 h-8 text-primary mb-3" />
          <p className="font-semibold">Exportar Excel/CSV</p>
          <p className="text-sm text-muted-foreground mt-1">Baixe todos os lançamentos em formato CSV.</p>
        </button>
        <button onClick={exportPDF} className="glass rounded-2xl p-6 text-left hover:shadow-glow transition">
          <FileText className="w-8 h-8 text-primary mb-3" />
          <p className="font-semibold">Relatório PDF</p>
          <p className="text-sm text-muted-foreground mt-1">Gere um PDF imprimível com todas as movimentações.</p>
        </button>
      </div>
      <div className="mt-6 grid sm:grid-cols-3 gap-4">
        <div className="glass rounded-2xl p-5"><p className="text-xs text-muted-foreground">Total receitas</p><p className="text-2xl font-display font-bold mt-2 text-success">{fmtBRL(receitas.reduce((s, r) => s + Number(r.valor), 0))}</p></div>
        <div className="glass rounded-2xl p-5"><p className="text-xs text-muted-foreground">Total despesas</p><p className="text-2xl font-display font-bold mt-2 text-destructive">{fmtBRL(despesas.reduce((s, r) => s + Number(r.valor), 0))}</p></div>
        <div className="glass rounded-2xl p-5"><p className="text-xs text-muted-foreground">Lançamentos</p><p className="text-2xl font-display font-bold mt-2">{receitas.length + despesas.length}</p></div>
      </div>
    </div>
  );
}
