import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL } from "@/lib/format";
import { PageHeader, EmptyState, StatCard } from "@/components/ui-bits";
import { Modal } from "@/components/TransactionList";
import { Plus, Trash2, Pencil, Loader2, TrendingUp, TrendingDown, ArrowDownCircle, ArrowUpCircle, History, Repeat } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/investimentos")({ component: InvPage });

type Inv = { id: string; nome: string; tipo: string; valor_investido: number; valor_atual: number; lucro: number; rentabilidade: number };
type MovTipo = "aporte" | "resgate" | "lucro" | "perda" | "reinvestimento";
type Mov = { id: string; investimento_id: string; tipo: MovTipo; valor: number; created_at: string };
type Acao = "lucro" | "resgate" | "reinvestir" | "aporte";

const TIPOS = ["Renda Fixa", "Ações", "Fundos", "Cripto", "Tesouro Direto", "Outros"];

function InvPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Inv[]>([]);
  const [movs, setMovs] = useState<Mov[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Inv | null>(null);
  const [moving, setMoving] = useState<{ inv: Inv; acao: Acao } | null>(null);
  const [historyFor, setHistoryFor] = useState<Inv | null>(null);

  const load = async () => {
    setLoading(true);
    const [i, mv] = await Promise.all([
      supabase.from("investimentos").select("*").order("created_at", { ascending: false }),
      supabase.from("investimento_movimentacoes").select("*").order("created_at", { ascending: false }),
    ]);
    setItems((i.data ?? []) as any);
    setMovs((mv.data ?? []) as any);
    setLoading(false);
  };
  useEffect(() => { if (user) load(); }, [user]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel(`inv-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "investimentos", filter: `user_id=eq.${user.id}` }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "investimento_movimentacoes", filter: `user_id=eq.${user.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const del = async (id: string) => {
    if (!confirm("Excluir investimento? O histórico também será removido.")) return;
    const { error } = await supabase.from("investimentos").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Excluído"); load(); }
  };

  const totalInv = items.reduce((s, x) => s + Number(x.valor_investido), 0);
  const totalAtual = items.reduce((s, x) => s + Number(x.valor_atual), 0);
  const lucro = totalAtual - totalInv;
  const rent = totalInv > 0 ? (lucro / totalInv) * 100 : 0;

  return (
    <div>
      <PageHeader title="Investimentos" subtitle="Aporte, resgate e acompanhe a rentabilidade em tempo real."
        action={<button onClick={() => { setEditing(null); setOpen(true); }} className="gradient-primary text-primary-foreground rounded-xl px-4 py-2.5 font-medium shadow-glow flex items-center gap-2"><Plus className="w-4 h-4" /> Novo</button>} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Investido" value={fmtBRL(totalInv)} />
        <StatCard label="Valor atual" value={fmtBRL(totalAtual)} accent />
        <StatCard label="Lucro" value={fmtBRL(lucro)} icon={<TrendingUp className="w-4 h-4 text-primary" />} />
        <StatCard label="Rentabilidade" value={`${rent.toFixed(2)}%`} />
      </div>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div> :
        items.length === 0 ? <EmptyState title="Nenhum investimento" desc="Adicione seu primeiro investimento para acompanhar." /> :
        <div className="grid md:grid-cols-2 gap-4">
          {items.map((i) => {
            const lucroInv = Number(i.valor_atual) - Number(i.valor_investido);
            const rentInv = Number(i.valor_investido) > 0 ? (lucroInv / Number(i.valor_investido)) * 100 : 0;
            const positivo = lucroInv >= 0;
            return (
              <div key={i.id} className="glass rounded-2xl p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{i.nome}</p>
                    <p className="text-xs text-muted-foreground">{i.tipo}</p>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => setHistoryFor(i)} className="p-2 rounded-lg hover:bg-secondary" title="Histórico"><History className="w-4 h-4" /></button>
                    <button onClick={() => { setEditing(i); setOpen(true); }} className="p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => del(i.id)} className="p-2 rounded-lg hover:bg-destructive/20 text-destructive"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Capital investido</p>
                    <p className="font-medium">{fmtBRL(i.valor_investido)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Valor atual</p>
                    <p className="font-medium">{fmtBRL(i.valor_atual)}</p>
                  </div>
                  <div className="col-span-2 rounded-xl bg-secondary/40 p-3 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Lucro acumulado</p>
                      <p className={`font-bold text-lg ${positivo ? "text-success" : "text-destructive"}`}>
                        {positivo ? "+" : ""}{fmtBRL(lucroInv)}
                      </p>
                    </div>
                    <div className={`flex items-center gap-1 text-sm font-semibold ${positivo ? "text-success" : "text-destructive"}`}>
                      {positivo ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                      {rentInv.toFixed(2)}%
                    </div>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <button onClick={() => setMoving({ inv: i, acao: "lucro" })} className="rounded-xl bg-success/15 hover:bg-success/25 text-success px-3 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 touch-manipulation">
                    <TrendingUp className="w-4 h-4" /> Lucro
                  </button>
                  <button onClick={() => setMoving({ inv: i, acao: "resgate" })} disabled={Number(i.valor_atual) <= 0} className="rounded-xl bg-primary/15 hover:bg-primary/25 text-primary px-3 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 touch-manipulation disabled:opacity-40 disabled:cursor-not-allowed">
                    <ArrowDownCircle className="w-4 h-4" /> Resgatar
                  </button>
                  <button onClick={() => setMoving({ inv: i, acao: "reinvestir" })} disabled={lucroInv <= 0} className="rounded-xl bg-accent/20 hover:bg-accent/30 text-foreground px-3 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 touch-manipulation disabled:opacity-40 disabled:cursor-not-allowed">
                    <Repeat className="w-4 h-4" /> Reinvestir
                  </button>
                  <button onClick={() => setMoving({ inv: i, acao: "aporte" })} className="rounded-xl bg-secondary hover:bg-secondary/70 px-3 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 touch-manipulation">
                    <ArrowUpCircle className="w-4 h-4" /> Aporte
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      }
      {open && <Modal onClose={() => { setOpen(false); setEditing(null); }}>
        <InvForm editing={editing} onSaved={() => { setOpen(false); setEditing(null); load(); }} />
      </Modal>}

      {moving && <Modal onClose={() => setMoving(null)}>
        <InvMovForm inv={moving.inv} acao={moving.acao} onDone={() => { setMoving(null); load(); }} />
      </Modal>}

      {historyFor && <Modal onClose={() => setHistoryFor(null)}>
        <InvHistoryView inv={historyFor} movs={movs.filter((x) => x.investimento_id === historyFor.id)} />
      </Modal>}
    </div>
  );
}

function InvForm({ editing, onSaved }: { editing: Inv | null; onSaved: () => void }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    nome: editing?.nome ?? "",
    tipo: editing?.tipo ?? TIPOS[0],
    valor_atual: Number(editing?.valor_atual ?? 0),
  });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); if (!user) return; setLoading(true);
    if (editing) {
      const va = Number(form.valor_atual);
      const { error } = await supabase.from("investimentos").update({
        nome: form.nome, tipo: form.tipo, valor_atual: va,
      }).eq("id", editing.id);
      setLoading(false);
      if (error) toast.error(error.message); else { toast.success("Salvo"); onSaved(); }
    } else {
      const v = Number(form.valor_atual);
      const { error } = await supabase.from("investimentos").insert({
        user_id: user.id, nome: form.nome, tipo: form.tipo,
        valor_investido: v, valor_atual: v,
      });
      setLoading(false);
      if (error) toast.error(error.message); else { toast.success("Criado"); onSaved(); }
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <h3 className="font-display text-xl font-bold">{editing ? "Editar investimento" : "Novo investimento"}</h3>
      <input required placeholder="Nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <select value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })} className="w-full bg-input rounded-xl px-4 py-3 outline-none">
        {TIPOS.map((t) => <option key={t} value={t}>{t}</option>)}
      </select>
      <div>
        <label className="text-xs text-muted-foreground">{editing ? "Valor atual (cotação atualizada)" : "Valor inicial investido"}</label>
        <input required type="text" inputMode="decimal" placeholder="0,00"
          value={form.valor_atual ? String(form.valor_atual).replace(".", ",") : ""}
          onChange={(e) => {
            const cleaned = e.target.value.replace(/[^0-9.,]/g, "").replace(",", ".");
            setForm({ ...form, valor_atual: parseFloat(cleaned) || 0 });
          }}
          className="w-full bg-input rounded-xl px-4 py-3 text-lg outline-none focus:ring-2 ring-primary mt-1" />
      </div>
      <p className="text-xs text-muted-foreground">Use os botões do card para registrar lucro, resgatar para o saldo ou reinvestir o lucro.</p>
      <button type="submit" disabled={loading} className="w-full gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60">
        {loading && <Loader2 className="w-4 h-4 animate-spin" />} Salvar
      </button>
    </form>
  );
}

const ACAO_CONFIG: Record<Acao, { title: string; rpc: string; cta: string; cor: string; help: string; allowNegative?: boolean }> = {
  lucro:      { title: "Registrar lucro / perda",   rpc: "investimento_lucro",              cta: "Registrar",       cor: "bg-success",     help: "Atualiza o valor atual do investimento sem mexer no seu saldo bancário. Use negativo para registrar perda.", allowNegative: true },
  resgate:    { title: "Resgatar para o saldo",     rpc: "investimento_resgatar",           cta: "Resgatar",        cor: "bg-primary",     help: "O valor sai do investimento e entra no seu saldo bancário." },
  reinvestir: { title: "Reinvestir lucro",          rpc: "investimento_reinvestir_lucro",   cta: "Reinvestir",      cor: "bg-accent",      help: "Move parte do lucro para o capital investido. Não mexe no seu saldo." },
  aporte:     { title: "Adicionar capital (aporte)", rpc: "investimento_aportar",           cta: "Adicionar",       cor: "bg-success",     help: "Aumenta seu capital investido. Não debita o saldo — registre manualmente a saída se houver." },
};

function InvMovForm({ inv, acao, onDone }: { inv: Inv; acao: Acao; onDone: () => void }) {
  const cfg = ACAO_CONFIG[acao];
  const [valor, setValor] = useState("");
  const [loading, setLoading] = useState(false);
  const lucroDisp = Number(inv.valor_atual) - Number(inv.valor_investido);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const raw = valor.replace(/\./g, "").replace(",", ".");
    const v = parseFloat(raw);
    if (isNaN(v) || v === 0) { toast.error("Valor inválido"); return; }
    if (!cfg.allowNegative && v <= 0) { toast.error("Valor inválido"); return; }
    if (acao === "resgate" && v > Number(inv.valor_atual)) { toast.error("Valor maior que o disponível no investimento"); return; }
    if (acao === "reinvestir" && v > lucroDisp) { toast.error(`Lucro disponível: ${fmtBRL(lucroDisp)}`); return; }
    setLoading(true);
    const { error } = await supabase.rpc(cfg.rpc as any, { _inv_id: inv.id, _valor: v });
    setLoading(false);
    if (error) toast.error(error.message);
    else { toast.success("Movimentação registrada"); onDone(); }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <h3 className="font-display text-xl font-bold">{cfg.title}</h3>
      <div className="text-sm text-muted-foreground space-y-1">
        <p><strong className="text-foreground">{inv.nome}</strong></p>
        <p>Valor atual: <span className="text-foreground">{fmtBRL(inv.valor_atual)}</span> · Investido: <span className="text-foreground">{fmtBRL(inv.valor_investido)}</span></p>
        <p>Lucro acumulado: <span className={lucroDisp >= 0 ? "text-success" : "text-destructive"}>{fmtBRL(lucroDisp)}</span></p>
      </div>
      <input
        required autoFocus type="text" inputMode={cfg.allowNegative ? "text" : "decimal"}
        placeholder={cfg.allowNegative ? "0,00 (use - para perda)" : "0,00"}
        value={valor}
        onChange={(e) => {
          const re = cfg.allowNegative ? /[^0-9.,\-]/g : /[^0-9.,]/g;
          setValor(e.target.value.replace(re, ""));
        }}
        className="w-full bg-input rounded-xl px-4 py-4 text-2xl font-bold outline-none focus:ring-2 ring-primary"
      />
      <p className="text-xs text-muted-foreground">{cfg.help}</p>
      <button type="submit" disabled={loading} className={`w-full text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60 ${cfg.cor}`}>
        {loading && <Loader2 className="w-4 h-4 animate-spin" />} {cfg.cta}
      </button>
    </form>
  );
}

const MOV_META: Record<MovTipo, { label: string; icon: typeof ArrowUpCircle; cor: string; sinal: string }> = {
  aporte:         { label: "Aporte de capital",  icon: ArrowUpCircle,   cor: "text-success",      sinal: "+" },
  lucro:          { label: "Lucro registrado",   icon: TrendingUp,      cor: "text-success",      sinal: "+" },
  perda:          { label: "Perda registrada",   icon: TrendingDown,    cor: "text-destructive",  sinal: "-" },
  resgate:        { label: "Resgate p/ saldo",   icon: ArrowDownCircle, cor: "text-primary",      sinal: "-" },
  reinvestimento: { label: "Reinvestimento",     icon: Repeat,          cor: "text-foreground",   sinal: "↻" },
};

function InvHistoryView({ inv, movs }: { inv: Inv; movs: Mov[] }) {
  return (
    <div className="space-y-3">
      <h3 className="font-display text-xl font-bold">Histórico — {inv.nome}</h3>
      {movs.length === 0 ? (
        <p className="text-sm text-muted-foreground py-8 text-center">Nenhuma movimentação ainda.</p>
      ) : (
        <div className="max-h-80 overflow-y-auto divide-y divide-border/40 -mx-2">
          {movs.map((m) => {
            const meta = MOV_META[m.tipo] ?? MOV_META.aporte;
            const Icon = meta.icon;
            return (
              <div key={m.id} className="flex items-center justify-between gap-3 px-2 py-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon className={`w-5 h-5 shrink-0 ${meta.cor}`} />
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{meta.label}</p>
                    <p className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleString("pt-BR")}</p>
                  </div>
                </div>
                <p className={`font-semibold ${meta.cor}`}>{meta.sinal} {fmtBRL(m.valor)}</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
