import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { fmtBRL, fmtDate } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui-bits";
import { Modal } from "@/components/TransactionList";
import { Plus, Trash2, Pencil, Loader2, Target, ArrowDownCircle, ArrowUpCircle, History } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/metas")({ component: MetasPage });

type Meta = { id: string; titulo: string; valor_meta: number; valor_atual: number; prazo: string | null };
type Mov = { id: string; meta_id: string; tipo: "aporte" | "resgate"; valor: number; created_at: string };

function MetasPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Meta[]>([]);
  const [movs, setMovs] = useState<Mov[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Meta | null>(null);
  const [moving, setMoving] = useState<{ meta: Meta; tipo: "aporte" | "resgate" } | null>(null);
  const [historyFor, setHistoryFor] = useState<Meta | null>(null);

  const load = async () => {
    setLoading(true);
    const [m, mv] = await Promise.all([
      supabase.from("metas").select("*").order("created_at", { ascending: false }),
      supabase.from("meta_movimentacoes").select("*").order("created_at", { ascending: false }),
    ]);
    setItems((m.data ?? []) as any);
    setMovs((mv.data ?? []) as any);
    setLoading(false);
  };
  useEffect(() => { if (user) load(); }, [user]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel(`metas-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "metas", filter: `user_id=eq.${user.id}` }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "meta_movimentacoes", filter: `user_id=eq.${user.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const del = async (id: string) => {
    if (!confirm("Excluir meta? O histórico também será removido.")) return;
    const { error } = await supabase.from("metas").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Excluído"); load(); }
  };

  return (
    <div>
      <PageHeader title="Metas financeiras" subtitle="Aporte e resgate diretamente — saldo atualizado automaticamente."
        action={<button onClick={() => { setEditing(null); setOpen(true); }} className="gradient-primary text-primary-foreground rounded-xl px-4 py-2.5 font-medium shadow-glow flex items-center gap-2"><Plus className="w-4 h-4" /> Nova meta</button>} />
      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div> :
        items.length === 0 ? <EmptyState title="Nenhuma meta ainda" desc="Crie sua primeira meta financeira." /> :
        <div className="grid md:grid-cols-2 gap-4">
          {items.map((m) => {
            const pct = Math.min(100, (Number(m.valor_atual) / Math.max(1, Number(m.valor_meta))) * 100);
            return (
              <div key={m.id} className="glass rounded-2xl p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shadow-glow shrink-0"><Target className="w-5 h-5 text-primary-foreground" /></div>
                    <div className="min-w-0">
                      <p className="font-semibold truncate">{m.titulo}</p>
                      {m.prazo && <p className="text-xs text-muted-foreground">Prazo: {fmtDate(m.prazo)}</p>}
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => setHistoryFor(m)} className="p-2 rounded-lg hover:bg-secondary" title="Histórico"><History className="w-4 h-4" /></button>
                    <button onClick={() => { setEditing(m); setOpen(true); }} className="p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => del(m.id)} className="p-2 rounded-lg hover:bg-destructive/20 text-destructive"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex justify-between text-xs mb-1.5"><span className="font-medium">{fmtBRL(m.valor_atual)}</span><span className="text-muted-foreground">{fmtBRL(m.valor_meta)}</span></div>
                  <div className="h-2.5 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full gradient-primary transition-all duration-500" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-xs text-primary mt-2 font-medium">{pct.toFixed(1)}% concluído</p>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <button onClick={() => setMoving({ meta: m, tipo: "aporte" })} className="rounded-xl bg-success/15 hover:bg-success/25 text-success px-3 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 touch-manipulation">
                    <ArrowUpCircle className="w-4 h-4" /> Adicionar
                  </button>
                  <button onClick={() => setMoving({ meta: m, tipo: "resgate" })} disabled={Number(m.valor_atual) <= 0} className="rounded-xl bg-destructive/15 hover:bg-destructive/25 text-destructive px-3 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 touch-manipulation disabled:opacity-40 disabled:cursor-not-allowed">
                    <ArrowDownCircle className="w-4 h-4" /> Resgatar
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      }

      {open && <Modal onClose={() => { setOpen(false); setEditing(null); }}>
        <MetaForm editing={editing} onSaved={() => { setOpen(false); setEditing(null); load(); }} />
      </Modal>}

      {moving && <Modal onClose={() => setMoving(null)}>
        <MovForm meta={moving.meta} tipo={moving.tipo} onDone={() => { setMoving(null); load(); }} />
      </Modal>}

      {historyFor && <Modal onClose={() => setHistoryFor(null)}>
        <HistoryView meta={historyFor} movs={movs.filter((x) => x.meta_id === historyFor.id)} />
      </Modal>}
    </div>
  );
}

function MetaForm({ editing, onSaved }: { editing: Meta | null; onSaved: () => void }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    titulo: editing?.titulo ?? "",
    valor_meta: Number(editing?.valor_meta ?? 0),
    prazo: editing?.prazo ?? "",
  });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    const payload: any = { ...form, user_id: user.id, prazo: form.prazo || null };
    const { error } = editing
      ? await supabase.from("metas").update(payload).eq("id", editing.id)
      : await supabase.from("metas").insert({ ...payload, valor_atual: 0 });
    setLoading(false);
    if (error) toast.error(error.message); else { toast.success("Salvo"); onSaved(); }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <h3 className="font-display text-xl font-bold">{editing ? "Editar meta" : "Nova meta"}</h3>
      <input required placeholder="Título da meta" value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <input required type="number" step="0.01" min="0.01" placeholder="Valor da meta" value={form.valor_meta || ""} onChange={(e) => setForm({ ...form, valor_meta: parseFloat(e.target.value) || 0 })} className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      <input type="date" value={form.prazo ?? ""} onChange={(e) => setForm({ ...form, prazo: e.target.value })} className="w-full bg-input rounded-xl px-4 py-3 outline-none focus:ring-2 ring-primary" />
      {!editing && <p className="text-xs text-muted-foreground">Use os botões "Adicionar" e "Resgatar" para movimentar valores depois.</p>}
      <button type="submit" disabled={loading} className="w-full gradient-primary text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60">
        {loading && <Loader2 className="w-4 h-4 animate-spin" />} Salvar
      </button>
    </form>
  );
}

function MovForm({ meta, tipo, onDone }: { meta: Meta; tipo: "aporte" | "resgate"; onDone: () => void }) {
  const [valor, setValor] = useState("");
  const [loading, setLoading] = useState(false);
  const isAporte = tipo === "aporte";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = parseFloat(valor.replace(",", "."));
    if (isNaN(v) || v <= 0) { toast.error("Valor inválido"); return; }
    if (!isAporte && v > Number(meta.valor_atual)) { toast.error("Valor maior que o guardado"); return; }
    setLoading(true);
    const fn = isAporte ? "meta_aportar" : "meta_resgatar";
    const { error } = await supabase.rpc(fn as any, { _meta_id: meta.id, _valor: v });
    setLoading(false);
    if (error) toast.error(error.message);
    else { toast.success(isAporte ? "Valor adicionado à meta" : "Valor resgatado para o saldo"); onDone(); }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <h3 className="font-display text-xl font-bold">{isAporte ? "Adicionar à meta" : "Resgatar da meta"}</h3>
      <div className="text-sm text-muted-foreground">
        <p><strong className="text-foreground">{meta.titulo}</strong></p>
        <p>Guardado: {fmtBRL(meta.valor_atual)} de {fmtBRL(meta.valor_meta)}</p>
      </div>
      <input
        required autoFocus type="text" inputMode="decimal"
        placeholder="0,00"
        value={valor}
        onChange={(e) => setValor(e.target.value.replace(/[^0-9.,]/g, ""))}
        className="w-full bg-input rounded-xl px-4 py-4 text-2xl font-bold outline-none focus:ring-2 ring-primary"
      />
      <p className="text-xs text-muted-foreground">
        {isAporte ? "O valor será debitado do seu saldo em conta." : "O valor será creditado no seu saldo em conta."}
      </p>
      <button type="submit" disabled={loading} className={`w-full text-primary-foreground rounded-xl py-3 font-semibold shadow-glow flex items-center justify-center gap-2 disabled:opacity-60 ${isAporte ? "bg-success" : "bg-destructive"}`}>
        {loading && <Loader2 className="w-4 h-4 animate-spin" />} {isAporte ? "Adicionar" : "Resgatar"}
      </button>
    </form>
  );
}

function HistoryView({ meta, movs }: { meta: Meta; movs: Mov[] }) {
  return (
    <div className="space-y-3">
      <h3 className="font-display text-xl font-bold">Histórico — {meta.titulo}</h3>
      {movs.length === 0 ? (
        <p className="text-sm text-muted-foreground py-8 text-center">Nenhuma movimentação ainda.</p>
      ) : (
        <div className="max-h-80 overflow-y-auto divide-y divide-border/40 -mx-2">
          {movs.map((m) => (
            <div key={m.id} className="flex items-center justify-between gap-3 px-2 py-3">
              <div className="flex items-center gap-2.5 min-w-0">
                {m.tipo === "aporte"
                  ? <ArrowUpCircle className="w-5 h-5 text-success shrink-0" />
                  : <ArrowDownCircle className="w-5 h-5 text-destructive shrink-0" />}
                <div className="min-w-0">
                  <p className="text-sm font-medium capitalize">{m.tipo}</p>
                  <p className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleString("pt-BR")}</p>
                </div>
              </div>
              <p className={`font-semibold ${m.tipo === "aporte" ? "text-success" : "text-destructive"}`}>
                {m.tipo === "aporte" ? "+" : "-"} {fmtBRL(m.valor)}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
