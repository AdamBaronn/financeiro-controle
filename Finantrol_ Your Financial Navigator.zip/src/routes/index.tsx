import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";
import { ArrowRight, BarChart3, CreditCard, PiggyBank, Shield, Sparkles, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen">
      {/* Nav */}
      <header className="sticky top-0 z-50 glass border-b border-border/40">
        <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
          <Logo />
          <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#recursos" className="hover:text-foreground transition">Recursos</a>
            <a href="#porque" className="hover:text-foreground transition">Por que</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/login" className="text-sm px-4 py-2 rounded-xl hover:bg-secondary transition">Entrar</Link>
            <Link to="/signup" className="text-sm px-4 py-2 rounded-xl gradient-primary text-primary-foreground font-medium shadow-glow">
              Começar grátis
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 pt-20 pb-28 text-center">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs text-muted-foreground mb-8">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            Plataforma financeira de nova geração
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
            Domine suas finanças
            <br />
            <span className="text-gradient">com inteligência.</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
            FINANTROL une o controle bancário ao design fintech moderno.
            Acompanhe receitas, despesas, metas, cartões e investimentos em tempo real.
          </p>
          <div className="mt-10 flex flex-wrap gap-3 justify-center">
            <Link
              to="/signup"
              className="inline-flex items-center gap-2 gradient-primary text-primary-foreground px-7 py-3.5 rounded-2xl font-semibold shadow-glow"
            >
              Criar conta <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 glass px-7 py-3.5 rounded-2xl font-semibold"
            >
              Já tenho conta
            </Link>
          </div>

          {/* Preview card */}
          <div className="mt-20 relative">
            <div className="glass-strong rounded-3xl p-6 md:p-8 shadow-card max-w-5xl mx-auto">
              <div className="grid md:grid-cols-3 gap-4">
                {[
                  { label: "Patrimônio total", value: "R$ 84.320,00", trend: "+12,4%" },
                  { label: "Receitas do mês", value: "R$ 12.800,00", trend: "+8,1%" },
                  { label: "Despesas do mês", value: "R$ 6.450,00", trend: "-3,2%" },
                ].map((c) => (
                  <div key={c.label} className="glass rounded-2xl p-5 text-left">
                    <p className="text-xs text-muted-foreground">{c.label}</p>
                    <p className="text-2xl font-display font-bold mt-2">{c.value}</p>
                    <p className="text-xs text-primary mt-1">{c.trend}</p>
                  </div>
                ))}
              </div>
              <div className="mt-6 h-40 rounded-2xl bg-gradient-to-br from-primary/20 to-transparent relative overflow-hidden">
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 160" preserveAspectRatio="none">
                  <path
                    d="M0,120 C50,80 100,140 150,90 C200,40 250,110 300,60 C350,20 400,80 400,80 L400,160 L0,160 Z"
                    fill="url(#g1)"
                  />
                  <path
                    d="M0,120 C50,80 100,140 150,90 C200,40 250,110 300,60 C350,20 400,80 400,80"
                    stroke="oklch(0.78 0.18 155)"
                    strokeWidth="2.5"
                    fill="none"
                  />
                  <defs>
                    <linearGradient id="g1" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.78 0.18 155)" stopOpacity="0.6" />
                      <stop offset="100%" stopColor="oklch(0.78 0.18 155)" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="recursos" className="mx-auto max-w-7xl px-6 py-24">
        <h2 className="font-display text-4xl md:text-5xl font-bold text-center">Tudo o que você precisa.</h2>
        <p className="text-muted-foreground text-center mt-3 max-w-xl mx-auto">
          Um ecossistema completo para sua vida financeira, do dia a dia até os investimentos.
        </p>
        <div className="grid md:grid-cols-3 gap-5 mt-14">
          {[
            { icon: BarChart3, title: "Dashboard em tempo real", desc: "Gráficos e métricas atualizadas instantaneamente." },
            { icon: PiggyBank, title: "Metas inteligentes", desc: "Defina objetivos e acompanhe o progresso automaticamente." },
            { icon: CreditCard, title: "Cartões e faturas", desc: "Limite, fechamento e vencimento em um só lugar." },
            { icon: TrendingUp, title: "Investimentos", desc: "Rentabilidade e lucro calculados sozinhos." },
            { icon: Shield, title: "Segurança bancária", desc: "Seus dados protegidos com RLS e criptografia." },
            { icon: Sparkles, title: "Design premium", desc: "Interface fintech moderna, fluida e responsiva." },
          ].map((f) => (
            <div key={f.title} className="glass rounded-2xl p-6 hover:shadow-glow transition-all">
              <div className="w-11 h-11 rounded-xl gradient-primary flex items-center justify-center mb-4">
                <f.icon className="w-5 h-5 text-primary-foreground" />
              </div>
              <h3 className="font-semibold text-lg">{f.title}</h3>
              <p className="text-sm text-muted-foreground mt-1.5">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section id="porque" className="mx-auto max-w-5xl px-6 py-24">
        <div className="glass-strong rounded-3xl p-12 text-center shadow-card">
          <h2 className="font-display text-4xl md:text-5xl font-bold">
            Pronto para começar?
          </h2>
          <p className="mt-4 text-muted-foreground">
            Crie sua conta gratuita em segundos. Sem cartão, sem complicação.
          </p>
          <Link
            to="/signup"
            className="mt-8 inline-flex items-center gap-2 gradient-primary text-primary-foreground px-8 py-4 rounded-2xl font-semibold shadow-glow"
          >
            Começar agora <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      <footer className="border-t border-border/40 mt-10">
        <div className="mx-auto max-w-7xl px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <Logo size={28} />
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} FINANTROL. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
